package com.velquora.aipvp.listener;

import com.velquora.aipvp.AiPvp;
import com.velquora.aipvp.bot.BotBrain;
import com.velquora.aipvp.bot.BotSession;
import com.velquora.aipvp.gui.MenuManager;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/**
 * Enterprise event listener managing GUI safety, combat isolation, environmental protection,
 * transactional block recording, projectile tracking, and death/respawn lifecycles.
 */
public class AiPvpListener implements Listener {

    private final AiPvp plugin;

    public AiPvpListener(AiPvp plugin) {
        this.plugin = plugin;
    }

    // ============================================================
    //                      GUI LISTENERS
    // ============================================================

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        String title = event.getView().getTitle();
        if (title.equals(MenuManager.MAIN_MENU_TITLE)) {
            event.setCancelled(true);
            if (event.getRawSlot() >= 0 && event.getRawSlot() < 27) {
                plugin.getMenuManager().handleMainMenuClick(player, event.getRawSlot());
            }
        } else if (title.equals(MenuManager.DIFFICULTY_MENU_TITLE)) {
            event.setCancelled(true);
            if (event.getRawSlot() >= 0 && event.getRawSlot() < 27) {
                plugin.getMenuManager().handleDifficultyMenuClick(player, event.getRawSlot());
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player player) {
            String title = event.getView().getTitle();
            if (title.equals(MenuManager.MAIN_MENU_TITLE) || title.equals(MenuManager.DIFFICULTY_MENU_TITLE)) {
                plugin.getMenuManager().clearPending(player.getUniqueId());
            }
        }
    }

    // ============================================================
    //           PART 7: DEATH & RESPAWN LIFECYCLE
    // ============================================================

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        BotSession session = plugin.getBotManager().getSession(player.getUniqueId());
        if (session != null && session.isActive()) {
            event.getDrops().clear();
            event.setDroppedExp(0);
            // End session without immediate state restoration inside death event
            session.end(BotSession.EndReason.BOT_WON);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        // Restore player state safely on respawn tick
        plugin.getBotManager().handleRespawn(player);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onEntityDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.hasMetadata("aipvp_bot")) {
            event.getDrops().clear();
            event.setDroppedExp(0);
            if (!entity.getMetadata("aipvp_owner").isEmpty()) {
                String ownerUuidStr = entity.getMetadata("aipvp_owner").get(0).asString();
                UUID ownerUuid = UUID.fromString(ownerUuidStr);
                BotSession session = plugin.getBotManager().getSession(ownerUuid);
                if (session != null && session.isActive()) {
                    session.end(BotSession.EndReason.PLAYER_WON);
                }
            }
        }
    }

    // ============================================================
    //      PART 8: ENVIRONMENTAL & COMBAT DAMAGE CONTROLS
    // ============================================================

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        if (!plugin.getConfigManager().getConfig().getBoolean("combat.protect-environment", true)) {
            return;
        }

        Entity victim = event.getEntity();
        boolean isParticipant = false;

        if (victim instanceof Player p) {
            isParticipant = plugin.getBotManager().isInSession(p.getUniqueId());
        } else if (victim.hasMetadata("aipvp_bot")) {
            isParticipant = true;
        }

        if (!isParticipant) return;

        ConfigurationSection causes = plugin.getConfigManager().getConfig().getConfigurationSection("combat.prevent-damage-causes");
        if (causes == null) return;

        EntityDamageEvent.DamageCause cause = event.getCause();

        if (causes.getBoolean("fall", false) && cause == EntityDamageEvent.DamageCause.FALL) {
            event.setCancelled(true);
        } else if (causes.getBoolean("fire", false) && (cause == EntityDamageEvent.DamageCause.FIRE || cause == EntityDamageEvent.DamageCause.FIRE_TICK)) {
            event.setCancelled(true);
        } else if (causes.getBoolean("lava", false) && cause == EntityDamageEvent.DamageCause.LAVA) {
            event.setCancelled(true);
        } else if (causes.getBoolean("drowning", true) && cause == EntityDamageEvent.DamageCause.DROWNING) {
            event.setCancelled(true);
        } else if (causes.getBoolean("suffocation", true) && cause == EntityDamageEvent.DamageCause.SUFFOCATION) {
            event.setCancelled(true);
        } else if (causes.getBoolean("cactus", false) && (cause == EntityDamageEvent.DamageCause.CONTACT)) {
            event.setCancelled(true);
        } else if (causes.getBoolean("lightning", true) && cause == EntityDamageEvent.DamageCause.LIGHTNING) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        Entity victim = event.getEntity();
        Entity damager = event.getDamager();

        if (damager instanceof Projectile proj && proj.getShooter() instanceof Entity shooterEntity) {
            damager = shooterEntity;
        }

        // Case 1: Bot is being attacked
        if (victim.hasMetadata("aipvp_bot")) {
            String ownerUuidStr = victim.getMetadata("aipvp_owner").isEmpty() ? null : victim.getMetadata("aipvp_owner").get(0).asString();
            if (ownerUuidStr != null) {
                UUID ownerUuid = UUID.fromString(ownerUuidStr);
                // Only session owner can damage this bot
                if (!(damager instanceof Player p) || !p.getUniqueId().equals(ownerUuid)) {
                    event.setCancelled(true);
                    return;
                }

                BotSession session = plugin.getBotManager().getSession(ownerUuid);
                if (session != null && session.getBotBrain() != null) {
                    BotBrain brain = session.getBotBrain();

                    // Check if bot is holding shield and blocking
                    if (brain.getShieldController().isBlocking()) {
                        ItemStack weapon = p.getInventory().getItemInMainHand();
                        if (weapon != null && isAxe(weapon.getType())) {
                            brain.getShieldController().disableShield((LivingEntity) victim);
                        } else {
                            event.setDamage(0.0);
                            event.setCancelled(true);
                            victim.getWorld().playSound(victim.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1.0f, 1.0f);
                            return;
                        }
                    }
                }
            }
        }

        // Case 2: Player is being attacked
        if (victim instanceof Player player) {
            BotSession session = plugin.getBotManager().getSession(player.getUniqueId());
            if (session != null && session.isActive()) {
                boolean isolated = plugin.getConfigManager().getConfig().getBoolean("session.isolated-combat", true);
                if (isolated) {
                    // Prevent external damage sources
                    if (damager.hasMetadata("aipvp_bot")) {
                        String botOwner = damager.getMetadata("aipvp_owner").get(0).asString();
                        if (!botOwner.equals(player.getUniqueId().toString())) {
                            event.setCancelled(true);
                        }
                    } else if (damager != player) {
                        event.setCancelled(true);
                    }
                }
            }
        }
    }

    private boolean isAxe(Material material) {
        return material == Material.NETHERITE_AXE
                || material == Material.DIAMOND_AXE
                || material == Material.IRON_AXE
                || material == Material.STONE_AXE
                || material == Material.WOODEN_AXE
                || material == Material.GOLDEN_AXE;
    }

    // ============================================================
    //    PART 2: TRANSACTION-STYLE BLOCK RECORDING BEFORE CHANGE
    // ============================================================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        BotSession session = plugin.getBotManager().getSession(player.getUniqueId());
        if (session != null && session.isActive()) {
            // Record original state BEFORE the break
            plugin.getArenaManager().getRollbackManager().recordPreModification(session.getSessionId(), event.getBlock());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        BotSession session = plugin.getBotManager().getSession(player.getUniqueId());
        if (session != null && session.isActive()) {
            // Record original block before the place
            plugin.getArenaManager().getRollbackManager().recordPreModification(session.getSessionId(), event.getBlockReplacedState().getBlock());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent event) {
        // Record all exploded blocks before they are removed
        for (BotSession session : plugin.getBotManager().getActiveSessions()) {
            if (session.isActive()) {
                plugin.getArenaManager().getRollbackManager().recordPreModifications(session.getSessionId(), event.blockList());
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent event) {
        for (BotSession session : plugin.getBotManager().getActiveSessions()) {
            if (session.isActive()) {
                plugin.getArenaManager().getRollbackManager().recordPreModifications(session.getSessionId(), event.blockList());
            }
        }
    }

    // ============================================================
    //       PART 3: PROJECTILE & ENTITY TRACKING
    // ============================================================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onProjectileLaunch(ProjectileLaunchEvent event) {
        Projectile projectile = event.getEntity();
        if (projectile.getShooter() instanceof Player player) {
            BotSession session = plugin.getBotManager().getSession(player.getUniqueId());
            if (session != null && session.isActive()) {
                plugin.getArenaManager().getEntityTracker().trackEntity(session.getSessionId(), projectile);
            }
        } else if (projectile.getShooter() instanceof LivingEntity living && living.hasMetadata("aipvp_bot")) {
            String owner = living.getMetadata("aipvp_owner").get(0).asString();
            BotSession session = plugin.getBotManager().getSession(UUID.fromString(owner));
            if (session != null && session.isActive()) {
                plugin.getArenaManager().getEntityTracker().trackEntity(session.getSessionId(), projectile);
            }
        }
    }

    // ============================================================
    //              DISCONNECT & TELEPORT SAFETY
    // ============================================================

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.getMenuManager().clearPending(player.getUniqueId());
        BotSession session = plugin.getBotManager().getSession(player.getUniqueId());
        if (session != null && session.isActive()) {
            session.end(BotSession.EndReason.PLAYER_QUIT);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerTeleport(PlayerTeleportEvent event) {
        Player player = event.getPlayer();
        BotSession session = plugin.getBotManager().getSession(player.getUniqueId());
        if (session != null && session.isActive() && event.getTo() != null && event.getFrom().getWorld() != null) {
            if (!event.getFrom().getWorld().equals(event.getTo().getWorld())) {
                session.end(BotSession.EndReason.CANCELLED);
            }
        }
    }
}
