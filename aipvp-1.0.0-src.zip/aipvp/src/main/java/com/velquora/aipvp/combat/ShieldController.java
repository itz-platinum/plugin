package com.velquora.aipvp.combat;

import com.velquora.aipvp.ai.DifficultyController;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Manages shield blocking, timing, and axe disabling for the bot.
 */
public class ShieldController {

    private final DifficultyController difficultyController;
    private boolean isBlocking = false;
    private int blockDurationTicks = 0;
    private int shieldDisabledTicks = 0;

    public ShieldController(DifficultyController difficultyController) {
        this.difficultyController = difficultyController;
    }

    public void tick(LivingEntity bot) {
        if (shieldDisabledTicks > 0) {
            shieldDisabledTicks--;
        }

        if (isBlocking) {
            blockDurationTicks--;
            if (blockDurationTicks <= 0) {
                stopBlocking(bot);
            }
        }
    }

    /**
     * Determines whether bot should raise shield in response to incoming attack.
     */
    public boolean considerBlocking(LivingEntity bot, double playerDistance) {
        if (shieldDisabledTicks > 0 || isBlocking) return false;
        if (playerDistance > 4.5) return false;

        double chance = difficultyController.getShieldBlockChance();
        if (ThreadLocalRandom.current().nextDouble() < chance) {
            startBlocking(bot);
            return true;
        }
        return false;
    }

    public void startBlocking(LivingEntity bot) {
        if (shieldDisabledTicks > 0 || bot == null) return;
        EntityEquipment eq = bot.getEquipment();
        if (eq == null) return;

        // Ensure shield in offhand
        if (eq.getItemInOffHand().getType() != Material.SHIELD) {
            eq.setItemInOffHand(new ItemStack(Material.SHIELD));
        }

        isBlocking = true;
        blockDurationTicks = 15 + ThreadLocalRandom.current().nextInt(15);
    }

    public void stopBlocking(LivingEntity bot) {
        isBlocking = false;
        blockDurationTicks = 0;
    }

    public void disableShield(LivingEntity bot) {
        isBlocking = false;
        blockDurationTicks = 0;
        shieldDisabledTicks = 100; // 5 seconds disable (Axe hit)
        if (bot != null && bot.getWorld() != null) {
            bot.getWorld().playSound(bot.getLocation(), Sound.ITEM_SHIELD_BREAK, 1.0f, 1.0f);
        }
    }

    public boolean isBlocking() {
        return isBlocking;
    }

    public boolean isShieldDisabled() {
        return shieldDisabledTicks > 0;
    }
}
