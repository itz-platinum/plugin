package com.velquora.aipvp.gemini;

/**
 * Immutable validated strategic decision produced by either Gemini or the Local Tactical Fallback.
 */
public record GeminiStrategicDecision(
        StrategicPlan plan,
        String priority,
        String targetBehavior,
        String riskLevel,
        String reasonCode,
        double confidence,
        long durationMs,
        long timestamp
) {
    public static GeminiStrategicDecision defaultFallback(StrategicPlan defaultPlan, String reason) {
        return new GeminiStrategicDecision(
                defaultPlan,
                "STANDARD",
                "BALANCED",
                "LOW",
                reason,
                0.75,
                3000L,
                System.currentTimeMillis()
        );
    }

    public boolean isExpired() {
        return (System.currentTimeMillis() - timestamp) > durationMs;
    }
}
