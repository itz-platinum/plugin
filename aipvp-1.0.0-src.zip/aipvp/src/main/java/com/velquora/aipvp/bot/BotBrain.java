package com.velquora.aipvp.bot;

import com.velquora.aipvp.AiPvp;
import com.velquora.aipvp.ai.*;
import com.velquora.aipvp.arena.Arena;
import com.velquora.aipvp.combat.*;
import com.velquora.aipvp.gemini.GeminiStrategicManager;
import com.velquora.aipvp.gemini.StrategicPlan;
import com.velquora.aipvp.kit.KitManager;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.UUID;

/**
 * Autonomous AI decision loop and tactical coordinator for the bot entity.
 * Blends high-frequency 20 TPS local physics/tactics with asynchronous Layer 2 strategic intelligence.
 */
public class BotBrain {

    private final AiPvp plugin;
    private final UUID sessionId;
    private final BotEntity botEntity;
    private final Player targetPlayer;
    private final Arena arena;
    private final KitManager.Mode mode;
    private final DifficultyController difficultyController;

    private final AimController aimController;
    private final MovementController movementController;
    private final CombatController combatController;
    private final TargetPrediction targetPrediction;
    private final PotionController potionController;
    private final ShieldController shieldController;

    private final NormalPvPController normalPvPController;
    private final CrystalPvPController crystalPvPController;
    private final MacePvPController macePvPController;
    private final GeminiStrategicManager geminiManager;

    private BukkitTask aiTask;
    private int reactionDelayCounter = 0;
    private int boundaryCheckCounter = 0;

    public BotBrain(AiPvp plugin,
                    UUID sessionId,
                    BotEntity botEntity,
                    Player targetPlayer,
                    Arena arena,
                    KitManager.Mode mode,
                    DifficultyController.Difficulty difficulty) {
        this.plugin = plugin;
        this.sessionId = sessionId;
        this.botEntity = botEntity;
        this.targetPlayer = targetPlayer;
        this.arena = arena;
        this.mode = mode;

        this.difficultyController = new DifficultyController(plugin, difficulty);
        this.aimController = new AimController(difficultyController);
        this.movementController = new MovementController(difficultyController);
        this.combatController = new CombatController(difficultyController);
        this.targetPrediction = new TargetPrediction();
        this.potionController = new PotionController(difficultyController);
        this.shieldController = new ShieldController(difficultyController);

        this.normalPvPController = new NormalPvPController(
                plugin, sessionId, aimController, movementController, combatController, targetPrediction, potionController, shieldController, difficultyController);

        this.crystalPvPController = new CrystalPvPController(
                plugin, sessionId, aimController, movementController, combatController, targetPrediction, potionController, difficultyController);

        this.macePvPController = new MacePvPController(
                plugin, sessionId, aimController, movementController, combatController, targetPrediction, potionController, difficultyController);

        this.geminiManager = new GeminiStrategicManager(plugin);
    }

    /**
     * Starts the scheduled AI decision loop.
     */
    public void start() {
        int interval = plugin.getConfigManager().getConfig().getInt("bot.ai-tick-interval", 1);
        if (interval < 1) interval = 1;

        aiTask = new BukkitRunnable() {
            @Override
            public void run() {
                tick();
            }
        }.runTaskTimer(plugin, 1L, interval);
    }

    /**
     * Single tick of authoritative AI computation.
     */
    public void tick() {
        if (!botEntity.isAlive() || targetPlayer == null || !targetPlayer.isOnline() || targetPlayer.isDead()) {
            return;
        }

        // 1. Update target velocity tracking
        targetPrediction.update(targetPlayer);

        // 2. Boundary enforcement (PART 6)
        boundaryCheckCounter++;
        if (boundaryCheckCounter >= 5) {
            boundaryCheckCounter = 0;
            if (arena != null && plugin.getConfigManager().getConfig().getBoolean("arena.enforce-boundary", true)) {
                String boundaryMode = plugin.getConfigManager().getConfig().getString("arena.boundary-mode", "soft");
                arena.enforceBoundary(botEntity.getEntity(), boundaryMode);
                arena.enforceBoundary(targetPlayer, boundaryMode);
            }
        }

        // 3. Update Strategic Intelligence Layer (Non-blocking async Gemini or local fallback)
        double remainingDist = (arena != null)
                ? (arena.getRadius() - arena.getHorizontalDistanceFromCenter(botEntity.getLocation()))
                : 20.0;
        geminiManager.evaluateState(mode, difficultyController.getDifficulty(), botEntity, targetPlayer, remainingDist);
        StrategicPlan activePlan = geminiManager.getActivePlan(mode);

        // 4. Reaction latency gate
        reactionDelayCounter++;
        if (reactionDelayCounter < difficultyController.getReactionDelayTicks()) {
            return;
        }
        reactionDelayCounter = 0;

        // 5. Delegate to Mode-specific controller with active strategy
        switch (mode) {
            case NORMAL_PVP -> normalPvPController.tick(botEntity, targetPlayer, activePlan);
            case CRYSTAL_PVP -> crystalPvPController.tick(botEntity, targetPlayer, activePlan);
            case MACE_PVP -> macePvPController.tick(botEntity, targetPlayer, activePlan);
        }
    }

    /**
     * Cancels the AI loop cleanly.
     */
    public void stop() {
        if (aiTask != null) {
            aiTask.cancel();
            aiTask = null;
        }
    }

    public ShieldController getShieldController() {
        return shieldController;
    }

    public GeminiStrategicManager getGeminiManager() {
        return geminiManager;
    }
}
