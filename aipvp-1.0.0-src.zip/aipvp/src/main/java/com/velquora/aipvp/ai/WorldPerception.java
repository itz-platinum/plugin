package com.velquora.aipvp.ai;

import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

/**
 * Structured 3D spatial perception and world analysis engine.
 * Computes line-of-sight ray traces, terrain stability, obstacle clearance, and tactical geometry.
 */
public class WorldPerception {

    public record EnvironmentScan(
            boolean hasDirectLineOfSight,
            double directDistance,
            double horizontalDistance,
            double heightDelta,
            boolean isPlayerAirborne,
            boolean isBotAirborne,
            boolean isObstacleAhead,
            int nearbyCrystalsCount,
            boolean isPlayerBlocking,
            boolean isPlayerSprinting
    ) {}

    /**
     * Conducts a real-time spatial evaluation of the combat field between bot and target player.
     */
    public static EnvironmentScan scan(LivingEntity bot, Player player) {
        if (bot == null || player == null || !bot.isValid() || !player.isOnline()) {
            return new EnvironmentScan(false, 999.0, 999.0, 0.0, false, false, false, 0, false, false);
        }

        Location botLoc = bot.getLocation();
        Location playerLoc = player.getLocation();
        World world = bot.getWorld();

        double directDist = botLoc.distance(playerLoc);
        double dx = playerLoc.getX() - botLoc.getX();
        double dz = playerLoc.getZ() - botLoc.getZ();
        double horizDist = Math.sqrt(dx * dx + dz * dz);
        double heightDelta = playerLoc.getY() - botLoc.getY();

        // 1. Ray trace line of sight
        boolean lineOfSight = false;
        Location eye = bot.getEyeLocation();
        Vector dir = player.getEyeLocation().toVector().subtract(eye.toVector());
        if (dir.lengthSquared() > 0.001) {
            RayTraceResult trace = world.rayTraceBlocks(eye, dir.normalize(), directDist, FluidCollisionMode.NEVER, true);
            lineOfSight = (trace == null || trace.getHitBlock() == null);
        }

        // 2. Airborne states
        boolean playerAirborne = !player.isOnGround() && player.getLocation().getBlock().getRelative(BlockFace.DOWN).getType().isAir();
        boolean botAirborne = !bot.isOnGround() && bot.getLocation().getBlock().getRelative(BlockFace.DOWN).getType().isAir();

        // 3. Obstacle in front of bot
        boolean obstacleAhead = false;
        Vector forward = botLoc.getDirection().setY(0);
        if (forward.lengthSquared() > 0.001) {
            Block blockAhead = botLoc.clone().add(forward.normalize().multiply(1.0)).getBlock();
            Block blockHead = blockAhead.getRelative(BlockFace.UP);
            obstacleAhead = (blockAhead.getType().isSolid() || blockHead.getType().isSolid());
        }

        // 4. Count nearby End Crystals in combat area
        int crystalCount = 0;
        for (Entity e : world.getNearbyEntities(playerLoc, 8.0, 8.0, 8.0)) {
            if (e instanceof EnderCrystal) {
                crystalCount++;
            }
        }

        boolean playerBlocking = player.isBlocking();
        boolean playerSprinting = player.isSprinting();

        return new EnvironmentScan(
                lineOfSight,
                directDist,
                horizDist,
                heightDelta,
                playerAirborne,
                botAirborne,
                obstacleAhead,
                crystalCount,
                playerBlocking,
                playerSprinting
        );
    }

    /**
     * Calculates estimated explosion damage and checks whether detonating at this point is safe for the bot.
     *
     * @param crystalLoc Candidate crystal position
     * @param botLoc Bot position
     * @param playerLoc Player position
     * @param maxAcceptableSelfDamage Max damage bot can take
     * @return true if candidate crystal is tactically favorable and safe
     */
    public static boolean isCrystalTacticallySafe(Location crystalLoc, Location botLoc, Location playerLoc, double maxAcceptableSelfDamage) {
        if (crystalLoc == null || botLoc == null || playerLoc == null) return false;

        double distToPlayer = crystalLoc.distance(playerLoc);
        double distToBot = crystalLoc.distance(botLoc);

        // Approximate explosion damage drop-off (vanilla Minecraft 1.21 power 6.0 explosion)
        double estimatedEnemyDamage = Math.max(0.0, (1.0 - (distToPlayer / 12.0)) * 24.0);
        double estimatedSelfDamage = Math.max(0.0, (1.0 - (distToBot / 12.0)) * 24.0);

        // Check feet/eye obstruction (obsidian shield dampens self damage)
        if (botLoc.getY() > crystalLoc.getY()) {
            estimatedSelfDamage *= 0.5; // Bot feet are protected by ground ledge
        }

        return (estimatedSelfDamage <= maxAcceptableSelfDamage) && (estimatedEnemyDamage > estimatedSelfDamage || distToPlayer < distToBot);
    }
}
