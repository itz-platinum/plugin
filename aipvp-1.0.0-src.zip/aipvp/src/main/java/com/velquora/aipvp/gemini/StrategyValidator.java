package com.velquora.aipvp.gemini;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.logging.Logger;

/**
 * Validates and sanitizes raw AI outputs.
 * Strictly guarantees that no arbitrary text or malicious input can affect server runtime.
 */
public class StrategyValidator {

    private final Logger logger;

    public StrategyValidator(Logger logger) {
        this.logger = logger;
    }

    /**
     * Parses and validates raw JSON output from Gemini into a verified GeminiStrategicDecision.
     */
    public GeminiStrategicDecision validate(String rawResponse, StrategicPlan fallbackPlan) {
        if (rawResponse == null || rawResponse.trim().isEmpty()) {
            return GeminiStrategicDecision.defaultFallback(fallbackPlan, "EMPTY_RESPONSE");
        }

        try {
            // Strip markdown block fences if present (```json ... ```)
            String clean = rawResponse.trim();
            if (clean.startsWith("```json")) {
                clean = clean.substring(7);
            } else if (clean.startsWith("```")) {
                clean = clean.substring(3);
            }
            if (clean.endsWith("```")) {
                clean = clean.substring(0, clean.length() - 3);
            }
            clean = clean.trim();

            JsonObject obj = JsonParser.parseString(clean).getAsJsonObject();

            String strategyStr = obj.has("strategy") ? obj.get("strategy").getAsString() : null;
            StrategicPlan plan = StrategicPlan.fromString(strategyStr, fallbackPlan);

            String priority = obj.has("priority") ? obj.get("priority").getAsString() : "STANDARD";
            String targetBehavior = obj.has("target_behavior") ? obj.get("target_behavior").getAsString() : "BALANCED";
            String riskLevel = obj.has("risk_level") ? obj.get("risk_level").getAsString() : "LOW";
            String reasonCode = obj.has("reason_code") ? obj.get("reason_code").getAsString() : "TACTICAL_EVALUATION";
            double confidence = obj.has("confidence") ? obj.get("confidence").getAsDouble() : 0.8;
            long durationMs = obj.has("duration_seconds") ? (long) (obj.get("duration_seconds").getAsDouble() * 1000L) : 3000L;
            durationMs = Math.min(8000L, Math.max(1000L, durationMs));

            return new GeminiStrategicDecision(
                    plan,
                    priority,
                    targetBehavior,
                    riskLevel,
                    reasonCode,
                    Math.max(0.0, Math.min(1.0, confidence)),
                    durationMs,
                    System.currentTimeMillis()
            );
        } catch (Exception e) {
            logger.fine("Failed to parse Gemini response as JSON: " + e.getMessage() + ". Raw: " + rawResponse);
            return GeminiStrategicDecision.defaultFallback(fallbackPlan, "PARSE_FAILURE");
        }
    }
}
