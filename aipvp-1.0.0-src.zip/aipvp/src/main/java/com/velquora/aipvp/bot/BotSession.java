package com.velquora.aipvp.bot;

import com.velquora.aipvp.AiPvp;
import com.velquora.aipvp.ai.DifficultyController;
import com.velquora.aipvp.arena.Arena;
import com.velquora.aipvp.kit.KitManager;
import com.velquora.aipvp.player.PlayerStateBackup;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Manages an isolated 1v1 PvP duel session between a player and an AI bot in a dedicated arena.
 */
public class BotSession {

    public enum EndReason {
        PLAYER_WON,
        BOT_WON,
        PLAYER_QUIT,
        TIMEOUT,
        CANCELLED
    }

    private final AiPvp plugin;
    private final UUID sessionId;
    private final Player player;
    private final Arena arena;
    private final KitManager.Mode mode;
    private final DifficultyController.Difficulty difficulty;

    private PlayerStateBackup stateBackup;
    private BotEntity botEntity;
    private BotBrain botBrain;
    private BukkitTask timeoutTask;
    private final AtomicBoolean active = new AtomicBoolean(false);

    public BotSession(AiPvp plugin, Player player, Arena arena, KitManager.Mode mode, DifficultyController.Difficulty difficulty) {
        this.plugin = plugin;
        this.sessionId = UUID.randomUUID();
        this.player = player;
        this.arena = arena;
        this.mode = mode;
        this.difficulty = difficulty;
    }

    /**
     * Initializes and starts the duel session in the assigned arena.
     */
    public boolean start() {
        if (arena == null || arena.getWorld() == null || arena.getPlayerSpawn() == null || arena.getBotSpawn() == null) {
            player.sendMessage(plugin.getConfigManager().getMessage("spawn-not-set", "§cConfigured duel arena is invalid or not loaded."));
            return false;
        }

        // 1. Transaction snapshot of player state
        this.stateBackup = new PlayerStateBackup(player);

        // 2. Prepare player vitals
        boolean resetVitals = plugin.getConfigManager().getConfig().getBoolean("session.reset-player-vitals-on-start", true);
        if (resetVitals) {
            for (PotionEffect effect : player.getActivePotionEffects()) {
                player.removePotionEffect(effect.getType());
            }
            player.setHealth(20.0);
            player.setFoodLevel(20);
            player.setSaturation(20.0f);
            player.setFireTicks(0);
        }

        // 3. Teleport player to dedicated arena spawn
        Location pSpawn = arena.getPlayerSpawn();
        player.teleport(pSpawn);

        // 4. Equip kit
        plugin.getKitManager().equipPlayer(player, mode);

        // 5. Spawn bot entity at arena bot spawn
        Location bSpawn = arena.getBotSpawn();
        botEntity = new BotEntity(plugin, player, mode);
        boolean spawned = botEntity.spawn(bSpawn, sessionId);
        if (!spawned) {
            stateBackup.restore(player, true);
            player.sendMessage("§cFailed to spawn AI bot entity.");
            plugin.getArenaManager().releaseArena(arena);
            return false;
        }

        // 6. Initialize Brain
        botBrain = new BotBrain(plugin, sessionId, botEntity, player, arena, mode, difficulty);
        botBrain.start();

        active.set(true);

        // 7. Timeout Task
        int maxDuration = plugin.getConfigManager().getConfig().getInt("session.max-duration-seconds", 600);
        if (maxDuration > 0) {
            timeoutTask = new BukkitRunnable() {
                @Override
                public void run() {
                    if (active.get()) {
                        end(EndReason.TIMEOUT);
                    }
                }
            }.runTaskLater(plugin, maxDuration * 20L);
        }

        // 8. Notification
        String botName = botEntity.getEntity() != null ? botEntity.getEntity().getCustomName() : player.getName() + "_bot";
        String startMsg = plugin.getConfigManager().getMessage("session-starting", "§aStarting duel in §e%arena%§a!")
                .replace("%mode%", mode.getDisplayName())
                .replace("%difficulty%", difficulty.getFormattedName())
                .replace("%bot%", botName)
                .replace("%arena%", arena.getDisplayName());
        player.sendMessage(startMsg);

        try {
            player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.7f, 1.2f);
        } catch (Exception ignored) {}

        return true;
    }

    /**
     * Ends the duel session safely, restoring all state and cleaning resources.
     */
    public synchronized void end(EndReason reason) {
        if (!active.compareAndSet(true, false)) {
            return;
        }

        // 1. Cancel timers
        if (timeoutTask != null) {
            timeoutTask.cancel();
            timeoutTask = null;
        }

        // 2. Stop Brain
        if (botBrain != null) {
            botBrain.stop();
        }

        // 3. Remove bot entity
        if (botEntity != null) {
            botEntity.remove();
        }

        // 4. PART 3: Complete Entity / Projectile cleanup
        if (plugin.getConfigManager().getConfig().getBoolean("arena.cleanup-entities", true)) {
            plugin.getArenaManager().getEntityTracker().cleanupSessionEntities(sessionId);
        }

        // 5. PART 2: Complete Transactional Block Rollback
        if (plugin.getConfigManager().getConfig().getBoolean("arena.cleanup-blocks", true)) {
            plugin.getArenaManager().getRollbackManager().rollbackSession(sessionId);
        }

        // 6. Release Arena back to available pool
        if (arena != null) {
            plugin.getArenaManager().releaseArena(arena);
        }

        // 7. PART 7: Player state restoration lifecycle
        boolean teleportBack = plugin.getConfigManager().getConfig().getBoolean("session.teleport-back-on-end", true);
        if (stateBackup != null && player != null && player.isOnline()) {
            if (player.isDead()) {
                // If player is dead, register snapshot for PlayerRespawnEvent!
                plugin.getBotManager().registerPendingRespawnRestore(player.getUniqueId(), stateBackup, teleportBack);
            } else {
                stateBackup.restore(player, teleportBack);
                player.sendMessage(plugin.getConfigManager().getMessage("state-restored", "§7Your state has been restored."));
            }
        }

        // 8. Outcome messages & sounds
        String botName = player.getName() + "_bot";
        if (player != null && player.isOnline() && !player.isDead()) {
            switch (reason) {
                case PLAYER_WON -> {
                    String winMsg = plugin.getConfigManager().getMessage("session-won", "§a§lVICTORY! §aYou have defeated §6%bot%§a!").replace("%bot%", botName);
                    player.sendMessage(winMsg);
                    try { player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f); } catch (Exception ignored) {}
                }
                case BOT_WON -> {
                    String lostMsg = plugin.getConfigManager().getMessage("session-lost", "§c§lDEFEAT! §cYou were defeated by §6%bot%§c!").replace("%bot%", botName);
                    player.sendMessage(lostMsg);
                    try { player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f); } catch (Exception ignored) {}
                }
                case TIMEOUT -> player.sendMessage(plugin.getConfigManager().getMessage("session-timeout", "§eSession timed out."));
                case CANCELLED -> player.sendMessage(plugin.getConfigManager().getMessage("session-cancelled", "§eSession cancelled."));
                case PLAYER_QUIT -> {}
            }
        }

        // 9. Deregister from BotManager
        plugin.getBotManager().removeSession(player.getUniqueId());
    }

    public UUID getSessionId() {
        return sessionId;
    }

    public Player getPlayer() {
        return player;
    }

    public Arena getArena() {
        return arena;
    }

    public BotEntity getBotEntity() {
        return botEntity;
    }

    public BotBrain getBotBrain() {
        return botBrain;
    }

    public boolean isActive() {
        return active.get();
    }

    public KitManager.Mode getMode() {
        return mode;
    }

    public DifficultyController.Difficulty getDifficulty() {
        return difficulty;
    }

    public PlayerStateBackup getStateBackup() {
        return stateBackup;
    }
}
