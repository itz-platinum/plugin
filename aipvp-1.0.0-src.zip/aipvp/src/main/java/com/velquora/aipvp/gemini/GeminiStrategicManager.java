package com.velquora.aipvp.gemini;

import com.velquora.aipvp.AiPvp;
import com.velquora.aipvp.ai.DifficultyController;
import com.velquora.aipvp.bot.BotEntity;
import com.velquora.aipvp.kit.KitManager;
import org.bukkit.entity.Player;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Coordinates asynchronous Layer 2 strategic intelligence.
 * Dispatches async requests, enforces single-request concurrency per session, caches postures,
 * and executes zero-latency fallbacks to Local Tactical AI.
 */
public class GeminiStrategicManager {

    private final AiPvp plugin;
    private final GeminiClient geminiClient;
    private final StrategyValidator validator;
    private final CombatMemory memory = new CombatMemory();

    private final AtomicBoolean isRequestInFlight = new AtomicBoolean(false);
    private GeminiStrategicDecision currentDecision;
    private long lastRequestTime = 0;

    public GeminiStrategicManager(AiPvp plugin) {
        this.plugin = plugin;
        this.geminiClient = new GeminiClient(plugin);
        this.validator = new StrategyValidator(plugin.getLogger());
        this.currentDecision = GeminiStrategicDecision.defaultFallback(StrategicPlan.PRESSURE, "INITIAL_STATE");
    }

    /**
     * Checks whether Gemini strategic layer is active and enabled in config.
     */
    public boolean isGeminiEnabled() {
        return plugin.getConfigManager().getConfig().getBoolean("gemini.enabled", false)
                && geminiClient.resolveApiKey() != null;
    }

    /**
     * Obtains the current active strategic posture (either verified from Gemini or local tactical fallback).
     */
    public StrategicPlan getActivePlan(KitManager.Mode mode) {
        if (currentDecision == null || currentDecision.isExpired()) {
            return getLocalDefaultPlan(mode);
        }
        return currentDecision.plan();
    }

    /**
     * Checks if a new strategic assessment should be scheduled.
     */
    public void evaluateState(
            KitManager.Mode mode,
            DifficultyController.Difficulty difficulty,
            BotEntity botEntity,
            Player player,
            double arenaRemainingDistance
    ) {
        if (player == null || botEntity == null || !botEntity.isAlive()) return;

        // Update local memory on every tick
        memory.update(player, player.getHealth(), botEntity.getLocation().distance(player.getLocation()));

        if (!isGeminiEnabled()) {
            // Local tactical calculation only
            currentDecision = GeminiStrategicDecision.defaultFallback(getLocalDefaultPlan(mode), "LOCAL_TACTICAL");
            return;
        }

        long now = System.currentTimeMillis();
        long intervalMs = plugin.getConfigManager().getConfig().getInt("gemini.decision-interval-ms", 3000);

        if ((now - lastRequestTime) < intervalMs) {
            return;
        }

        // Ensure at most ONE concurrent request in flight
        if (!isRequestInFlight.compareAndSet(false, true)) {
            return;
        }

        lastRequestTime = now;
        String stateJson = CombatStateSerializer.serialize(mode, difficulty, botEntity, player, memory, arenaRemainingDistance);

        // Execute asynchronous HTTP call without stalling the Paper server thread
        geminiClient.requestStrategicDecision(stateJson)
                .thenAccept(rawJson -> {
                    StrategicPlan fallback = getLocalDefaultPlan(mode);
                    GeminiStrategicDecision decision = validator.validate(rawJson, fallback);
                    this.currentDecision = decision;
                    isRequestInFlight.set(false);

                    if (plugin.getConfigManager().getConfig().getBoolean("debug.gemini", false)) {
                        plugin.getLogger().info("[AiPvP Gemini] Adopted strategy: " + decision.plan() + " (Confidence: " + decision.confidence() + ")");
                    }
                })
                .exceptionally(ex -> {
                    isRequestInFlight.set(false);
                    return null;
                });
    }

    /**
     * Instantaneous Local Tactical AI default fallback when Gemini is disabled, lagging, or offline.
     */
    public StrategicPlan getLocalDefaultPlan(KitManager.Mode mode) {
        return switch (mode) {
            case NORMAL_PVP -> StrategicPlan.PRESSURE;
            case CRYSTAL_PVP -> StrategicPlan.CRYSTAL_PRESSURE;
            case MACE_PVP -> StrategicPlan.MACE_ATTACK;
        };
    }

    public CombatMemory getMemory() {
        return memory;
    }

    public GeminiStrategicDecision getCurrentDecision() {
        return currentDecision;
    }
}
