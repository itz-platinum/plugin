package com.velquora.aipvp.command;

import com.velquora.aipvp.AiPvp;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;
import java.util.logging.Level;

/**
 * Command handler for /aipvp - opens the PvP training mode GUI for players.
 */
public class AiPvpCommand implements CommandExecutor, TabCompleter {

    private final AiPvp plugin;

    public AiPvpCommand(AiPvp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        try {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(plugin.getConfigManager().getMessage("only-players", "§cThis command can only be used by players."));
                return true;
            }

            if (!player.hasPermission("aipvp.use")) {
                player.sendMessage(plugin.getConfigManager().getMessage("no-permission", "§cYou do not have permission to execute this command."));
                return true;
            }

            plugin.getMenuManager().openMainMenu(player);
            return true;
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Error while processing /aipvp command", e);
            sender.sendMessage("§cAn error occurred while opening the AiPvP menu. Please contact an administrator.");
            return true;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return Collections.emptyList();
    }
}
