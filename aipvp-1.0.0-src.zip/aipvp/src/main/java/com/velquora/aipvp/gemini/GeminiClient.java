package com.velquora.aipvp.gemini;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.velquora.aipvp.AiPvp;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;

/**
 * Asynchronous non-blocking HTTP client for Google Gemini REST API.
 * Uses Java 11+ standard HttpClient without external heavy SDK dependencies.
 */
public class GeminiClient {

    private final AiPvp plugin;
    private final HttpClient httpClient;

    public GeminiClient(AiPvp plugin) {
        this.plugin = plugin;
        this.httpClient = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .connectTimeout(Duration.ofMillis(1200))
                .build();
    }

    /**
     * Resolves the Gemini API key from environment variable or secure config.
     */
    public String resolveApiKey() {
        String envName = plugin.getConfigManager().getConfig().getString("gemini.api-key-env", "GEMINI_API_KEY");
        String key = System.getenv(envName);
        if (key != null && !key.trim().isEmpty()) {
            return key.trim();
        }
        String configKey = plugin.getConfigManager().getConfig().getString("gemini.api-key", "");
        return (configKey != null && !configKey.trim().isEmpty()) ? configKey.trim() : null;
    }

    /**
     * Sends an asynchronous strategic evaluation request to Gemini.
     *
     * @param combatStateJson JSON formatted battle state
     * @return CompletableFuture with the extracted JSON text response from Gemini
     */
    public CompletableFuture<String> requestStrategicDecision(String combatStateJson) {
        String apiKey = resolveApiKey();
        if (apiKey == null) {
            return CompletableFuture.completedFuture(null);
        }

        String model = plugin.getConfigManager().getConfig().getString("gemini.model", "gemini-2.5-flash");
        int timeoutMs = plugin.getConfigManager().getConfig().getInt("gemini.timeout-ms", 1500);

        String endpoint = String.format(
                "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s",
                model, apiKey
        );

        String systemPrompt =
                "You are an expert Minecraft PvP strategic AI. Given a live 1v1 combat state, select the optimal tactical posture. " +
                "Respond ONLY with a valid JSON object matching this exact schema: " +
                "{\"strategy\":\"<STRATEGY>\",\"priority\":\"<PRIORITY>\",\"target_behavior\":\"<BEHAVIOR>\",\"risk_level\":\"<LOW|MEDIUM|HIGH>\",\"reason_code\":\"<CODE>\",\"confidence\":0.9,\"duration_seconds\":3.0}. " +
                "Allowed values for strategy: PRESSURE, DEFEND, RETREAT, HEAL, REPOSITION, BOW_PRESSURE, BREAK_SHIELD, CRYSTAL_SETUP, CRYSTAL_PRESSURE, MACE_SETUP, MACE_ATTACK, RESET_POSITION.";

        JsonObject root = new JsonObject();

        // System Instruction
        JsonObject sysInstruction = new JsonObject();
        JsonArray sysParts = new JsonArray();
        JsonObject sysPart = new JsonObject();
        sysPart.addProperty("text", systemPrompt);
        sysParts.add(sysPart);
        sysInstruction.add("parts", sysParts);
        root.add("system_instruction", sysInstruction);

        // Contents
        JsonArray contents = new JsonArray();
        JsonObject userContent = new JsonObject();
        userContent.addProperty("role", "user");
        JsonArray userParts = new JsonArray();
        JsonObject statePart = new JsonObject();
        statePart.addProperty("text", combatStateJson);
        userParts.add(statePart);
        userContent.add("parts", userParts);
        contents.add(userContent);
        root.add("contents", contents);

        // Generation Config for JSON mode
        JsonObject genConfig = new JsonObject();
        genConfig.addProperty("responseMimeType", "application/json");
        genConfig.addProperty("temperature", 0.3);
        root.add("generationConfig", genConfig);

        String requestBody = root.toString();

        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(endpoint))
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofMillis(timeoutMs))
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();

            return httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenApply(response -> {
                        if (response.statusCode() == 200) {
                            return extractCandidateText(response.body());
                        } else {
                            if (plugin.getConfigManager().getConfig().getBoolean("debug.gemini", false)) {
                                plugin.getLogger().warning("Gemini API non-200 status: " + response.statusCode() + " body: " + response.body());
                            }
                            return null;
                        }
                    })
                    .exceptionally(ex -> {
                        if (plugin.getConfigManager().getConfig().getBoolean("debug.gemini", false)) {
                            plugin.getLogger().log(Level.FINE, "Gemini API request failed/timed out: " + ex.getMessage());
                        }
                        return null;
                    });
        } catch (Exception e) {
            return CompletableFuture.completedFuture(null);
        }
    }

    private String extractCandidateText(String responseBody) {
        try {
            JsonObject json = JsonParser.parseString(responseBody).getAsJsonObject();
            JsonArray candidates = json.getAsJsonArray("candidates");
            if (candidates != null && !candidates.isEmpty()) {
                JsonObject first = candidates.get(0).getAsJsonObject();
                JsonObject content = first.getAsJsonObject("content");
                if (content != null) {
                    JsonArray parts = content.getAsJsonArray("parts");
                    if (parts != null && !parts.isEmpty()) {
                        return parts.get(0).getAsJsonObject().get("text").getAsString();
                    }
                }
            }
        } catch (Exception ignored) {}
        return null;
    }
}
