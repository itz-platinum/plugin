package com.velquora.aipvp.gemini;

import com.velquora.aipvp.AiPvp;
import com.velquora.aipvp.ai.WorldPerception;
import com.velquora.aipvp.bot.BotEntity;
import org.bukkit.entity.Player;

/**
 * Manages spatial and visual perception analysis.
 * Generates structured 3D spatial descriptors for strategic AI reasoning.
 */
public class VisualAnalysisManager {

    private final AiPvp plugin;

    public VisualAnalysisManager(AiPvp plugin) {
        this.plugin = plugin;
    }

    public boolean isVisualAiEnabled() {
        return plugin.getConfigManager().getConfig().getBoolean("visual-ai.enabled", false);
    }

    /**
     * Builds a structured scene description from server geometry.
     */
    public String describeScene(BotEntity bot, Player player) {
        if (bot == null || player == null || !bot.isAlive() || !player.isOnline()) {
            return "Combatants not in line of sight.";
        }

        WorldPerception.EnvironmentScan scan = WorldPerception.scan(bot.getEntity(), player);

        return String.format(
                "Line of Sight: %s | Distance: %.1fm (Horiz: %.1fm, Height Delta: %.1fm) | " +
                "Player State: [Airborne: %s, Blocking: %s, Sprinting: %s] | " +
                "Terrain: [Obstacle Ahead: %s, Surrounding End Crystals: %d]",
                scan.hasDirectLineOfSight() ? "CLEAR" : "OBSTRUCTED",
                scan.directDistance(),
                scan.horizontalDistance(),
                scan.heightDelta(),
                scan.isPlayerAirborne(),
                scan.isPlayerBlocking(),
                scan.isPlayerSprinting(),
                scan.isObstacleAhead(),
                scan.nearbyCrystalsCount()
        );
    }
}
