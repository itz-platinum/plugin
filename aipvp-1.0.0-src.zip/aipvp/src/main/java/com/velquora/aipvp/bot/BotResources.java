package com.velquora.aipvp.bot;

import com.velquora.aipvp.kit.KitManager;

/**
 * Tracks actual consumable resources available to the AI bot during a duel session.
 * Prevents phantom or infinite item utilization.
 */
public class BotResources {

    private int goldenApples;
    private int arrows;
    private int endCrystals;
    private int obsidian;
    private int enderPearls;
    private int windCharges;
    private int splashPotions;
    private int totems;

    public BotResources(KitManager.Mode mode) {
        // Initialize based on mode loadouts
        switch (mode) {
            case NORMAL_PVP -> {
                this.goldenApples = 16;
                this.arrows = 64;
                this.endCrystals = 0;
                this.obsidian = 0;
                this.enderPearls = 0;
                this.windCharges = 0;
                this.splashPotions = 4;
                this.totems = 0;
            }
            case CRYSTAL_PVP -> {
                this.goldenApples = 32;
                this.arrows = 0;
                this.endCrystals = 64;
                this.obsidian = 64;
                this.enderPearls = 16;
                this.windCharges = 0;
                this.splashPotions = 8;
                this.totems = 4;
            }
            case MACE_PVP -> {
                this.goldenApples = 16;
                this.arrows = 0;
                this.endCrystals = 0;
                this.obsidian = 0;
                this.enderPearls = 16;
                this.windCharges = 64;
                this.splashPotions = 6;
                this.totems = 1;
            }
        }
    }

    public synchronized boolean useGoldenApple() {
        if (goldenApples > 0) {
            goldenApples--;
            return true;
        }
        return false;
    }

    public synchronized boolean useArrow() {
        if (arrows > 0) {
            arrows--;
            return true;
        }
        return false;
    }

    public synchronized boolean useEndCrystal() {
        if (endCrystals > 0) {
            endCrystals--;
            return true;
        }
        return false;
    }

    public synchronized boolean useObsidian() {
        if (obsidian > 0) {
            obsidian--;
            return true;
        }
        return false;
    }

    public synchronized boolean useEnderPearl() {
        if (enderPearls > 0) {
            enderPearls--;
            return true;
        }
        return false;
    }

    public synchronized boolean useWindCharge() {
        if (windCharges > 0) {
            windCharges--;
            return true;
        }
        return false;
    }

    public synchronized boolean useSplashPotion() {
        if (splashPotions > 0) {
            splashPotions--;
            return true;
        }
        return false;
    }

    public synchronized boolean useTotem() {
        if (totems > 0) {
            totems--;
            return true;
        }
        return false;
    }

    public int getGoldenApples() { return goldenApples; }
    public int getArrows() { return arrows; }
    public int getEndCrystals() { return endCrystals; }
    public int getObsidian() { return obsidian; }
    public int getEnderPearls() { return enderPearls; }
    public int getWindCharges() { return windCharges; }
    public int getSplashPotions() { return splashPotions; }
    public int getTotems() { return totems; }
}
