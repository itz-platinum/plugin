package com.velquora.aipvp.gemini;

import com.velquora.aipvp.ai.DifficultyController;
import com.velquora.aipvp.ai.WorldPerception;
import com.velquora.aipvp.bot.BotEntity;
import com.velquora.aipvp.bot.BotResources;
import com.velquora.aipvp.kit.KitManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * Serializes the current active duel situation into a compact JSON payload for Gemini.
 */
public class CombatStateSerializer {

    public static String serialize(
            KitManager.Mode mode,
            DifficultyController.Difficulty difficulty,
            BotEntity botEntity,
            Player player,
            CombatMemory memory,
            double arenaRemainingDistance
    ) {
        if (botEntity == null || player == null || !botEntity.isAlive() || !player.isOnline()) {
            return "{}";
        }

        WorldPerception.EnvironmentScan scan = WorldPerception.scan(botEntity.getEntity(), player);
        BotResources res = botEntity.getResources();

        double botHp = Math.round(botEntity.getEntity().getHealth() * 10.0) / 10.0;
        double playerHp = Math.round(player.getHealth() * 10.0) / 10.0;
        double dist = Math.round(scan.directDistance() * 10.0) / 10.0;

        ItemStack playerMain = player.getInventory().getItemInMainHand();
        String playerWeapon = (playerMain != null && playerMain.getType() != Material.AIR)
                ? playerMain.getType().name() : "HAND";

        String behaviorSummary = memory.getBehavioralSummary().replace("\"", "'");

        return String.format(
                "{" +
                "\"mode\":\"%s\"," +
                "\"difficulty\":\"%s\"," +
                "\"bot_health\":%.1f," +
                "\"player_health\":%.1f," +
                "\"distance\":%.1f," +
                "\"player_weapon\":\"%s\"," +
                "\"player_blocking\":%b," +
                "\"line_of_sight\":%b," +
                "\"bot_crystals\":%d," +
                "\"bot_obsidian\":%d," +
                "\"bot_totems\":%d," +
                "\"bot_wind_charges\":%d," +
                "\"bot_gapples\":%d," +
                "\"arena_boundary_remaining\":%.1f," +
                "\"observed_player_behavior\":\"%s\"" +
                "}",
                mode.name(),
                difficulty.name(),
                botHp,
                playerHp,
                dist,
                playerWeapon,
                scan.isPlayerBlocking(),
                scan.hasDirectLineOfSight(),
                res.getEndCrystals(),
                res.getObsidian(),
                res.getTotems(),
                res.getWindCharges(),
                res.getGoldenApples(),
                Math.max(0.0, Math.round(arenaRemainingDistance * 10.0) / 10.0),
                behaviorSummary
        );
    }
}
