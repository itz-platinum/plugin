package com.velquora.aipvp.ai;

import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Calculates vector aiming, yaw, pitch, and rotational tracking with difficulty-based inaccuracy.
 */
public class AimController {

    private final DifficultyController difficultyController;

    public AimController(DifficultyController difficultyController) {
        this.difficultyController = difficultyController;
    }

    /**
     * Rotates the bot smoothly to face the target position.
     *
     * @param bot The bot living entity
     * @param targetLoc Target position to look at
     */
    public void lookAt(LivingEntity bot, Location targetLoc) {
        if (bot == null || !bot.isValid() || targetLoc == null) return;

        Location botEye = bot.getEyeLocation();
        Vector direction = targetLoc.toVector().subtract(botEye.toVector());

        // Apply inaccuracy error based on difficulty
        double accuracy = difficultyController.getAimAccuracy();
        if (accuracy < 0.999) {
            double errorFactor = (1.0 - accuracy) * 1.5;
            double offsetX = (ThreadLocalRandom.current().nextDouble() - 0.5) * errorFactor;
            double offsetY = (ThreadLocalRandom.current().nextDouble() - 0.5) * errorFactor * 0.5;
            double offsetZ = (ThreadLocalRandom.current().nextDouble() - 0.5) * errorFactor;
            direction.add(new Vector(offsetX, offsetY, offsetZ));
        }

        if (direction.lengthSquared() < 0.001) return;

        Location newLoc = bot.getLocation().clone();
        newLoc.setDirection(direction.normalize());
        bot.setRotation(newLoc.getYaw(), newLoc.getPitch());
    }

    /**
     * Calculates the direct unit direction vector from bot eye to target.
     */
    public Vector getDirectionToTarget(LivingEntity bot, Location target) {
        if (bot == null || target == null) return new Vector(0, 0, 1);
        Location botEye = bot.getEyeLocation();
        return target.toVector().subtract(botEye.toVector()).normalize();
    }
}
