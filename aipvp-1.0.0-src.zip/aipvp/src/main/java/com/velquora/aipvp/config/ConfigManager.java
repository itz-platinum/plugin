package com.velquora.aipvp.config;

import com.velquora.aipvp.AiPvp;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;

/**
 * Handles initialization, loading, saving, and reloading of all plugin YAML configuration files.
 */
public class ConfigManager {

    private final AiPvp plugin;

    private File configFile;
    private FileConfiguration config;

    private File kitsFile;
    private FileConfiguration kitsConfig;

    private File difficultyFile;
    private FileConfiguration difficultyConfig;

    private File messagesFile;
    private FileConfiguration messagesConfig;

    private File arenasFile;
    private FileConfiguration arenasConfig;

    public ConfigManager(AiPvp plugin) {
        this.plugin = plugin;
    }

    /**
     * Loads or creates all configuration files.
     */
    public void loadAll() {
        configFile = new File(plugin.getDataFolder(), "config.yml");
        kitsFile = new File(plugin.getDataFolder(), "kits.yml");
        difficultyFile = new File(plugin.getDataFolder(), "difficulty.yml");
        messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        arenasFile = new File(plugin.getDataFolder(), "arenas.yml");

        saveDefault("config.yml", configFile);
        saveDefault("kits.yml", kitsFile);
        saveDefault("difficulty.yml", difficultyFile);
        saveDefault("messages.yml", messagesFile);
        saveDefault("arenas.yml", arenasFile);

        config = YamlConfiguration.loadConfiguration(configFile);
        kitsConfig = YamlConfiguration.loadConfiguration(kitsFile);
        difficultyConfig = YamlConfiguration.loadConfiguration(difficultyFile);
        messagesConfig = YamlConfiguration.loadConfiguration(messagesFile);
        arenasConfig = YamlConfiguration.loadConfiguration(arenasFile);

        syncDefaults(config, "config.yml");
        syncDefaults(kitsConfig, "kits.yml");
        syncDefaults(difficultyConfig, "difficulty.yml");
        syncDefaults(messagesConfig, "messages.yml");
        syncDefaults(arenasConfig, "arenas.yml");
    }

    private void saveDefault(String resourceName, File targetFile) {
        if (!targetFile.exists()) {
            targetFile.getParentFile().mkdirs();
            plugin.saveResource(resourceName, false);
        }
    }

    private void syncDefaults(FileConfiguration loadedConfig, String resourceName) {
        try (InputStream stream = plugin.getResource(resourceName)) {
            if (stream != null) {
                YamlConfiguration defConfig = YamlConfiguration.loadConfiguration(new InputStreamReader(stream, StandardCharsets.UTF_8));
                loadedConfig.setDefaults(defConfig);
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Failed to sync defaults for " + resourceName, e);
        }
    }

    public void saveConfig() {
        try {
            if (config != null && configFile != null) {
                config.save(configFile);
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save config.yml", e);
        }
    }

    public void saveArenas() {
        try {
            if (arenasConfig != null && arenasFile != null) {
                arenasConfig.save(arenasFile);
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save arenas.yml", e);
        }
    }

    public String getMessage(String key, String fallback) {
        if (messagesConfig == null) {
            return ChatColor.translateAlternateColorCodes('&', fallback);
        }
        String prefix = messagesConfig.getString("prefix", "§8[§6AiPvP§8] §r");
        String raw = messagesConfig.getString("messages." + key, fallback);
        String colored = ChatColor.translateAlternateColorCodes('&', raw);
        return prefix + colored;
    }

    public String getRawMessage(String key, String fallback) {
        if (messagesConfig == null) {
            return ChatColor.translateAlternateColorCodes('&', fallback);
        }
        String raw = messagesConfig.getString("messages." + key, fallback);
        return ChatColor.translateAlternateColorCodes('&', raw);
    }

    public FileConfiguration getConfig() {
        return config;
    }

    public FileConfiguration getKitsConfig() {
        return kitsConfig;
    }

    public FileConfiguration getDifficultyConfig() {
        return difficultyConfig;
    }

    public FileConfiguration getMessagesConfig() {
        return messagesConfig;
    }

    public FileConfiguration getArenasConfig() {
        return arenasConfig;
    }
}
