package com.velquora.aipvp.gemini;

/**
 * Validated, finite set of strategic postures allowable from the Gemini AI layer.
 * Strictly prevents arbitrary command execution or unverified actions.
 */
public enum StrategicPlan {
    PRESSURE("Aggressive forward pursuit, closing gap with crits"),
    DEFEND("Defensive posture, raise shield and observe"),
    RETREAT("Tactical withdrawal, creating distance"),
    HEAL("Disengage to splash healing or consume golden apple"),
    REPOSITION("Flank or circle opponent for positional advantage"),
    BOW_PRESSURE("Distance spacing with charged arrow shots"),
    BREAK_SHIELD("Prioritize axe switch to disable player shield"),
    CRYSTAL_SETUP("Deploy obsidian base and prep End Crystal combo"),
    CRYSTAL_PRESSURE("Aggressive crystal placement and fast detonation"),
    MACE_SETUP("Gain vertical elevation via wind charge propulsion"),
    MACE_ATTACK("Execute falling downward heavy mace smash"),
    RESET_POSITION("Regain center arena control");

    private final String description;

    StrategicPlan(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public static StrategicPlan fromString(String name, StrategicPlan fallback) {
        if (name == null || name.trim().isEmpty()) return fallback;
        String clean = name.trim().toUpperCase().replace("-", "_").replace(" ", "_");
        for (StrategicPlan plan : values()) {
            if (plan.name().equals(clean)) {
                return plan;
            }
        }
        return fallback;
    }
}
