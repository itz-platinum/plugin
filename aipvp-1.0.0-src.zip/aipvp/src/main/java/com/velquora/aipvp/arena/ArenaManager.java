package com.velquora.aipvp.arena;

import com.velquora.aipvp.AiPvp;
import com.velquora.aipvp.kit.KitManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Manages multi-arena registration, selection, availability states, and boundary enforcement.
 */
public class ArenaManager {

    private final AiPvp plugin;
    private final Map<String, Arena> arenas = new ConcurrentHashMap<>();
    private final ArenaRollbackManager rollbackManager;
    private final EntityTracker entityTracker;

    public ArenaManager(AiPvp plugin) {
        this.plugin = plugin;
        this.rollbackManager = new ArenaRollbackManager(plugin);
        this.entityTracker = new EntityTracker(plugin);
    }

    /**
     * Loads all arenas from arenas.yml with fallback handling.
     */
    public void loadArenas() {
        arenas.clear();
        ConfigurationSection section = plugin.getConfigManager().getArenasConfig().getConfigurationSection("arenas");

        if (section != null) {
            for (String key : section.getKeys(false)) {
                try {
                    ConfigurationSection arenaSec = section.getConfigurationSection(key);
                    if (arenaSec == null) continue;

                    String displayName = arenaSec.getString("display-name", key);
                    String worldName = arenaSec.getString("world", "world");
                    double radius = arenaSec.getDouble("radius", 30.0);
                    boolean enabled = arenaSec.getBoolean("enabled", true);
                    List<String> allowedModes = arenaSec.getStringList("allowed-modes");

                    Location playerSpawn = parseLocation(arenaSec.getConfigurationSection("player-spawn"), worldName);
                    Location botSpawn = parseLocation(arenaSec.getConfigurationSection("bot-spawn"), worldName);

                    Arena arena = new Arena(key, displayName, worldName, playerSpawn, botSpawn, radius);
                    arena.setEnabled(enabled);
                    arena.setAllowedModes(allowedModes);

                    arenas.put(key.toLowerCase(), arena);
                } catch (Exception e) {
                    plugin.getLogger().log(Level.WARNING, "Failed to load arena '" + key + "': " + e.getMessage());
                }
            }
        }

        // If no arenas exist in arenas.yml, build fallback arena from config.yml
        if (arenas.isEmpty()) {
            buildFallbackArena();
        }

        plugin.getLogger().info("[AiPvP] Loaded " + arenas.size() + " duel arenas from configuration.");
    }

    private void buildFallbackArena() {
        ConfigurationSection botSpawnSec = plugin.getConfigManager().getConfig().getConfigurationSection("bot-spawn");
        String worldName = (botSpawnSec != null) ? botSpawnSec.getString("world", "world") : "world";
        Location botSpawn = parseLocation(botSpawnSec, worldName);
        if (botSpawn == null) {
            World w = Bukkit.getWorlds().isEmpty() ? null : Bukkit.getWorlds().get(0);
            if (w != null) {
                botSpawn = new Location(w, 0.5, 64.0, 0.5, 0.0f, 0.0f);
            }
        }

        Location playerSpawn = (botSpawn != null) ? botSpawn.clone().add(0, 0, 8) : null;
        if (playerSpawn != null) {
            playerSpawn.setYaw(180.0f);
        }

        Arena fallback = new Arena("default", "Default Arena", worldName, playerSpawn, botSpawn, 30.0);
        arenas.put("default", fallback);
    }

    private Location parseLocation(ConfigurationSection sec, String defaultWorld) {
        if (sec == null) return null;
        String wName = sec.getString("world", defaultWorld);
        World world = Bukkit.getWorld(wName);
        if (world == null) return null;

        double x = sec.getDouble("x");
        double y = sec.getDouble("y");
        double z = sec.getDouble("z");
        float yaw = (float) sec.getDouble("yaw", 0.0);
        float pitch = (float) sec.getDouble("pitch", 0.0);

        return new Location(world, x, y, z, yaw, pitch);
    }

    /**
     * Acquires an available enabled arena that supports the specified PvP mode.
     */
    public synchronized Arena acquireArena(KitManager.Mode mode, UUID sessionId) {
        for (Arena arena : arenas.values()) {
            if (arena.isEnabled() && arena.getStatus() == Arena.Status.AVAILABLE) {
                if (arena.isModeAllowed(mode.name()) && arena.getWorld() != null) {
                    if (arena.acquire(sessionId)) {
                        rollbackManager.registerSession(sessionId);
                        entityTracker.registerSession(sessionId);
                        return arena;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Releases an arena back to available pool.
     */
    public synchronized void releaseArena(Arena arena) {
        if (arena != null) {
            arena.release();
        }
    }

    public Arena getArena(String id) {
        if (id == null) return null;
        return arenas.get(id.toLowerCase());
    }

    public Collection<Arena> getAllArenas() {
        return Collections.unmodifiableCollection(arenas.values());
    }

    /**
     * Compatibility helper: Returns the bot spawn location for the default or first available arena.
     */
    public Location getBotSpawnLocation() {
        Arena defaultArena = arenas.get("default");
        if (defaultArena != null && defaultArena.getBotSpawn() != null) {
            return defaultArena.getBotSpawn();
        }
        for (Arena a : arenas.values()) {
            if (a.getBotSpawn() != null) return a.getBotSpawn();
        }
        return null;
    }

    /**
     * Saves a player's current location as the default bot spawn point.
     */
    public void setBotSpawnLocation(Location loc) {
        if (loc == null || loc.getWorld() == null) return;

        Arena defaultArena = arenas.computeIfAbsent("default", k ->
                new Arena("default", "Default Arena", loc.getWorld().getName(), loc.clone().add(0, 0, 8), loc.clone(), 30.0));

        defaultArena.setBotSpawn(loc.clone());
        defaultArena.setWorldName(loc.getWorld().getName());

        ConfigurationSection section = plugin.getConfigManager().getConfig().getConfigurationSection("bot-spawn");
        if (section == null) {
            section = plugin.getConfigManager().getConfig().createSection("bot-spawn");
        }
        section.set("world", loc.getWorld().getName());
        section.set("x", Math.round(loc.getX() * 100.0) / 100.0);
        section.set("y", Math.round(loc.getY() * 100.0) / 100.0);
        section.set("z", Math.round(loc.getZ() * 100.0) / 100.0);
        section.set("yaw", Math.round(loc.getYaw() * 10.0f) / 10.0f);
        section.set("pitch", Math.round(loc.getPitch() * 10.0f) / 10.0f);
        plugin.getConfigManager().saveConfig();
    }

    public ArenaRollbackManager getRollbackManager() {
        return rollbackManager;
    }

    public EntityTracker getEntityTracker() {
        return entityTracker;
    }

    public void cleanupAll() {
        rollbackManager.rollbackAll();
        entityTracker.cleanupAll();
        for (Arena arena : arenas.values()) {
            arena.release();
        }
    }
}
