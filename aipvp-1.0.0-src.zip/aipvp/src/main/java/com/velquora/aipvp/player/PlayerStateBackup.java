package com.velquora.aipvp.player;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Immutable transaction-style snapshot of a player's complete state prior to entering an AiPvP session.
 * Guarantees idempotent and zero-loss state restoration across wins, quits, timeouts, and death/respawns.
 */
public class PlayerStateBackup {

    private final Location location;
    private final ItemStack[] inventoryContents;
    private final ItemStack[] armorContents;
    private final ItemStack offHandItem;
    private final double health;
    private final double maxHealth;
    private final int foodLevel;
    private final float saturation;
    private final float exhaustion;
    private final int level;
    private final float exp;
    private final int totalExperience;
    private final GameMode gameMode;
    private final Collection<PotionEffect> activePotionEffects;
    private final int fireTicks;
    private final int remainingAir;
    private final float fallDistance;
    private final boolean allowFlight;
    private final boolean isFlying;
    private final double absorptionAmount;

    private final AtomicBoolean restored = new AtomicBoolean(false);

    public PlayerStateBackup(Player player) {
        this.location = player.getLocation().clone();

        // Deep clone inventory items to prevent reference mutation
        ItemStack[] originalInv = player.getInventory().getContents();
        this.inventoryContents = new ItemStack[originalInv.length];
        for (int i = 0; i < originalInv.length; i++) {
            this.inventoryContents[i] = (originalInv[i] != null) ? originalInv[i].clone() : null;
        }

        ItemStack[] originalArmor = player.getInventory().getArmorContents();
        this.armorContents = new ItemStack[originalArmor.length];
        for (int i = 0; i < originalArmor.length; i++) {
            this.armorContents[i] = (originalArmor[i] != null) ? originalArmor[i].clone() : null;
        }

        ItemStack offhand = player.getInventory().getItemInOffHand();
        this.offHandItem = (offhand != null) ? offhand.clone() : null;

        this.maxHealth = getPlayerMaxHealth(player);
        this.health = Math.min(player.getHealth(), this.maxHealth);
        this.foodLevel = player.getFoodLevel();
        this.saturation = player.getSaturation();
        this.exhaustion = player.getExhaustion();
        this.level = player.getLevel();
        this.exp = player.getExp();
        this.totalExperience = player.getTotalExperience();
        this.gameMode = player.getGameMode();
        this.activePotionEffects = new ArrayList<>(player.getActivePotionEffects());
        this.fireTicks = Math.max(0, player.getFireTicks());
        this.remainingAir = player.getRemainingAir();
        this.fallDistance = player.getFallDistance();
        this.allowFlight = player.getAllowFlight();
        this.isFlying = player.isFlying();
        this.absorptionAmount = player.getAbsorptionAmount();
    }

    /**
     * Restores the player's saved state. Safe to call multiple times (idempotent).
     *
     * @param player the player to restore
     * @param teleport whether to teleport back to the pre-session location
     * @return true if restored, false if already restored or player invalid
     */
    public synchronized boolean restore(Player player, boolean teleport) {
        if (!restored.compareAndSet(false, true)) {
            return false;
        }
        if (player == null || !player.isOnline()) {
            return false;
        }

        // Clear temporary effects first
        for (PotionEffect effect : player.getActivePotionEffects()) {
            player.removePotionEffect(effect.getType());
        }

        // Restore inventory & equipment
        player.getInventory().clear();
        player.getInventory().setContents(this.inventoryContents);
        player.getInventory().setArmorContents(this.armorContents);
        player.getInventory().setItemInOffHand(this.offHandItem);

        // Restore vital stats safely
        AttributeInstance maxHpAttr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (maxHpAttr != null && this.maxHealth > 0) {
            maxHpAttr.setBaseValue(this.maxHealth);
        }

        double safeHp = Math.min(this.health, getPlayerMaxHealth(player));
        player.setHealth(Math.max(1.0, safeHp));
        player.setAbsorptionAmount(this.absorptionAmount);
        player.setFoodLevel(this.foodLevel);
        player.setSaturation(this.saturation);
        player.setExhaustion(this.exhaustion);
        player.setLevel(this.level);
        player.setExp(this.exp);
        player.setTotalExperience(this.totalExperience);
        player.setGameMode(this.gameMode);
        player.setFireTicks(this.fireTicks);
        player.setRemainingAir(this.remainingAir);
        player.setFallDistance(this.fallDistance);
        player.setAllowFlight(this.allowFlight);
        if (this.allowFlight) {
            player.setFlying(this.isFlying);
        }

        // Reapply saved potion effects
        for (PotionEffect effect : this.activePotionEffects) {
            player.addPotionEffect(effect);
        }

        // Teleport back if requested and location world is valid
        if (teleport && this.location != null && this.location.getWorld() != null) {
            player.teleport(this.location);
        }

        player.updateInventory();
        return true;
    }

    private double getPlayerMaxHealth(Player player) {
        AttributeInstance attr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        return (attr != null) ? attr.getValue() : 20.0;
    }

    public Location getLocation() {
        return location != null ? location.clone() : null;
    }

    public boolean isRestored() {
        return restored.get();
    }
}
