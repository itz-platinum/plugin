package com.velquora.aipvp.ai;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/**
 * Predicts player velocity and future location for projectile aiming and intercept pathing.
 */
public class TargetPrediction {

    private Vector previousPlayerLocation = null;
    private Vector currentVelocity = new Vector(0, 0, 0);
    private Vector smoothedVelocity = new Vector(0, 0, 0);

    /**
     * Updates recorded velocity on tick.
     */
    public void update(Player player) {
        if (player == null || !player.isOnline()) return;

        Vector currentPos = player.getLocation().toVector();
        if (previousPlayerLocation != null) {
            // Delta per tick
            currentVelocity = currentPos.clone().subtract(previousPlayerLocation);
            // Exponential smoothing
            smoothedVelocity = smoothedVelocity.clone().multiply(0.6).add(currentVelocity.clone().multiply(0.4));
        }
        previousPlayerLocation = currentPos;
    }

    /**
     * Predicts the player's position after a given number of ticks.
     *
     * @param player Target player
     * @param ticksInFuture Lookahead ticks
     * @param predictionFactor 0.0 (no lead) to 1.0 (full accurate lead)
     * @return predicted Location
     */
    public Location predictPosition(Player player, double ticksInFuture, double predictionFactor) {
        Location baseLoc = player.getLocation().clone();
        if (predictionFactor <= 0.001 || smoothedVelocity == null) {
            return baseLoc;
        }

        Vector lead = smoothedVelocity.clone().multiply(ticksInFuture * predictionFactor);
        // Cap maximum lead distance to 8 blocks to avoid overshooting on sudden teleports/knockback
        if (lead.lengthSquared() > 64.0) {
            lead.normalize().multiply(8.0);
        }

        return baseLoc.add(lead);
    }

    /**
     * Calculates intercept angle / vector for projectile throwing (Arrows, Wind Charges, Splash Pots).
     */
    public Vector calculateTrajectory(Location source, Location target, double projectileSpeed, double gravity) {
        Vector diff = target.toVector().subtract(source.toVector());
        double dx = diff.getX();
        double dz = diff.getZ();
        double dy = diff.getY();
        double distHoriz = Math.sqrt(dx * dx + dz * dz);

        if (distHoriz < 0.1) {
            return new Vector(0, dy > 0 ? 1 : -1, 0);
        }

        // Standard ballistic elevation calculation
        double v2 = projectileSpeed * projectileSpeed;
        double v4 = v2 * v2;
        double g = gravity;
        double inside = v4 - g * (g * distHoriz * distHoriz + 2 * dy * v2);

        double pitch;
        if (inside < 0) {
            // Out of range, aim at 45 degrees
            pitch = Math.PI / 4.0;
        } else {
            pitch = Math.atan((v2 - Math.sqrt(inside)) / (g * distHoriz));
        }

        double yaw = Math.atan2(-dx, dz);
        double vx = -Math.sin(yaw) * Math.cos(pitch) * projectileSpeed;
        double vz = Math.cos(yaw) * Math.cos(pitch) * projectileSpeed;
        double vy = Math.sin(pitch) * projectileSpeed;

        return new Vector(vx, vy, vz);
    }

    public Vector getSmoothedVelocity() {
        return smoothedVelocity.clone();
    }
}
