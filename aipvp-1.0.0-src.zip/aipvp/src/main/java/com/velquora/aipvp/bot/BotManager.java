package com.velquora.aipvp.bot;

import com.velquora.aipvp.AiPvp;
import com.velquora.aipvp.ai.DifficultyController;
import com.velquora.aipvp.arena.Arena;
import com.velquora.aipvp.kit.KitManager;
import com.velquora.aipvp.player.PlayerStateBackup;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Collection;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registry and lifecycle manager for all concurrent independent AiPvP duel sessions.
 */
public class BotManager {

    public record PendingRestore(PlayerStateBackup backup, boolean teleport) {}

    private final AiPvp plugin;
    private final Map<UUID, BotSession> activeSessions = new ConcurrentHashMap<>();
    private final Map<UUID, PendingRestore> pendingRespawnRestores = new ConcurrentHashMap<>();

    public BotManager(AiPvp plugin) {
        this.plugin = plugin;
    }

    /**
     * Starts a new duel session for the player by acquiring an available arena.
     */
    public boolean createSession(Player player, KitManager.Mode mode, DifficultyController.Difficulty difficulty) {
        if (player == null || !player.isOnline()) return false;

        if (isInSession(player.getUniqueId())) {
            player.sendMessage(plugin.getConfigManager().getMessage("already-in-session", "§cYou are already in an active AiPvP duel!"));
            return false;
        }

        // Acquire an available arena supporting this mode
        UUID tempSessionId = UUID.randomUUID();
        Arena arena = plugin.getArenaManager().acquireArena(mode, tempSessionId);
        if (arena == null) {
            player.sendMessage(plugin.getConfigManager().getMessage("no-available-arena", "§cAll compatible PvP arenas are currently in use! Please wait."));
            return false;
        }

        BotSession session = new BotSession(plugin, player, arena, mode, difficulty);
        boolean success = session.start();
        if (success) {
            activeSessions.put(player.getUniqueId(), session);
            return true;
        } else {
            plugin.getArenaManager().releaseArena(arena);
            return false;
        }
    }

    public boolean isInSession(UUID playerUuid) {
        BotSession session = activeSessions.get(playerUuid);
        return session != null && session.isActive();
    }

    public BotSession getSession(UUID playerUuid) {
        return activeSessions.get(playerUuid);
    }

    public void removeSession(UUID playerUuid) {
        activeSessions.remove(playerUuid);
    }

    /**
     * Registers a pending state restoration to execute on PlayerRespawnEvent.
     */
    public void registerPendingRespawnRestore(UUID playerUuid, PlayerStateBackup backup, boolean teleport) {
        if (playerUuid != null && backup != null) {
            pendingRespawnRestores.put(playerUuid, new PendingRestore(backup, teleport));
        }
    }

    /**
     * Called during PlayerRespawnEvent to restore player state safely.
     */
    public void handleRespawn(Player player) {
        if (player == null) return;
        PendingRestore pending = pendingRespawnRestores.remove(player.getUniqueId());
        if (pending != null) {
            // Run 1 tick after respawn to guarantee player entity is fully reset by server
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (player.isOnline()) {
                        pending.backup().restore(player, pending.teleport());
                        player.sendMessage(plugin.getConfigManager().getMessage("state-restored", "§7Your state has been restored."));
                    }
                }
            }.runTaskLater(plugin, 1L);
        }
    }

    /**
     * Terminates all active sessions safely (used during plugin disable / reload).
     */
    public void terminateAll() {
        for (BotSession session : activeSessions.values()) {
            try {
                session.end(BotSession.EndReason.CANCELLED);
            } catch (Exception e) {
                plugin.getLogger().warning("Error terminating session for player " + session.getPlayer().getName() + ": " + e.getMessage());
            }
        }
        activeSessions.clear();

        // Flush any pending respawns for online players
        for (Map.Entry<UUID, PendingRestore> entry : pendingRespawnRestores.entrySet()) {
            Player p = plugin.getServer().getPlayer(entry.getKey());
            if (p != null && p.isOnline()) {
                entry.getValue().backup().restore(p, entry.getValue().teleport());
            }
        }
        pendingRespawnRestores.clear();
    }

    public Collection<BotSession> getActiveSessions() {
        return activeSessions.values();
    }
}
