package com.velquora.aipvp.ai;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;

/**
 * Handles attack cooldowns, melee reach, critical hit detection, and damage execution.
 */
public class CombatController {

    private final DifficultyController difficultyController;
    private int attackCooldownTicks = 0;
    private int itemSwitchDelayTicks = 0;

    public CombatController(DifficultyController difficultyController) {
        this.difficultyController = difficultyController;
    }

    public void tick() {
        if (attackCooldownTicks > 0) {
            attackCooldownTicks--;
        }
        if (itemSwitchDelayTicks > 0) {
            itemSwitchDelayTicks--;
        }
    }

    /**
     * Checks whether the bot can perform a melee swing on the player.
     */
    public boolean canAttack(LivingEntity bot, Player target, double maxReach) {
        if (attackCooldownTicks > 0 || bot == null || !bot.isValid() || target == null || !target.isOnline()) {
            return false;
        }
        double dist = bot.getLocation().distance(target.getLocation());
        return dist <= maxReach;
    }

    /**
     * Executes a melee strike from the bot against the player.
     */
    public boolean performMeleeAttack(LivingEntity bot, Player target) {
        if (!canAttack(bot, target, 3.5)) {
            return false;
        }

        // Reset attack cooldown based on difficulty
        attackCooldownTicks = difficultyController.getAttackDelayTicks();

        // Simulate critical hit if falling
        boolean isCrit = bot.getFallDistance() > 0.0F && !bot.isOnGround();
        double baseDamage = 7.0; // Sharpness netherite sword standard

        EntityEquipment eq = bot.getEquipment();
        if (eq != null && eq.getItemInMainHand() != null) {
            switch (eq.getItemInMainHand().getType()) {
                case NETHERITE_AXE, DIAMOND_AXE -> baseDamage = 9.0;
                case MACE -> {
                    double fallBonus = Math.min(15.0, bot.getFallDistance() * 2.5);
                    baseDamage = 8.0 + fallBonus;
                }
                case NETHERITE_SWORD -> baseDamage = 8.0;
                case DIAMOND_SWORD -> baseDamage = 7.0;
                default -> baseDamage = 5.0;
            }
        }

        if (isCrit) {
            baseDamage *= 1.5;
            target.getWorld().spawnParticle(Particle.CRIT, target.getLocation().add(0, 1.0, 0), 15, 0.2, 0.2, 0.2, 0.1);
            target.getWorld().playSound(target.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
        } else {
            target.getWorld().spawnParticle(Particle.SWEEP_ATTACK, target.getLocation().add(0, 1.0, 0), 1);
            target.getWorld().playSound(target.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 1.0f);
        }

        target.damage(baseDamage, bot);
        return true;
    }

    public boolean canSwitchItem() {
        return itemSwitchDelayTicks <= 0;
    }

    public void triggerItemSwitchCooldown() {
        this.itemSwitchDelayTicks = difficultyController.getItemSwitchDelayTicks();
    }

    public int getAttackCooldownTicks() {
        return attackCooldownTicks;
    }

    public void resetCooldown() {
        this.attackCooldownTicks = difficultyController.getAttackDelayTicks();
    }
}
