package com.velquora.aipvp.ai;

import com.velquora.aipvp.AiPvp;
import org.bukkit.configuration.ConfigurationSection;

/**
 * Manages difficulty intelligence profiles (Easy, Medium, Hard).
 * Controls reaction latency, aim precision, combat timing, and tactical decision weighting.
 * STRICT RULE: Difficulty NEVER alters bot max health, base damage, or armor values.
 */
public class DifficultyController {

    public enum Difficulty {
        EASY("Easy", "§a"),
        MEDIUM("Medium", "§e"),
        HARD("Hard", "§c");

        private final String displayName;
        private final String colorCode;

        Difficulty(String displayName, String colorCode) {
            this.displayName = displayName;
            this.colorCode = colorCode;
        }

        public String getDisplayName() {
            return displayName;
        }

        public String getFormattedName() {
            return colorCode + displayName;
        }
    }

    private final AiPvp plugin;
    private final Difficulty difficulty;

    private int reactionDelayTicks = 5;
    private double aimAccuracy = 0.85;
    private int attackDelayTicks = 13;
    private double movementAggressiveness = 0.75;
    private double strafingIntensity = 0.65;
    private double healingThreshold = 0.50;
    private int itemSwitchDelayTicks = 6;
    private double targetPredictionFactor = 0.60;
    private double shieldBlockChance = 0.70;
    private int crystalPlacementDelay = 10;
    private double maceWindChargeChance = 0.65;

    public DifficultyController(AiPvp plugin, Difficulty difficulty) {
        this.plugin = plugin;
        this.difficulty = difficulty;
        loadSettings();
    }

    public void loadSettings() {
        if (plugin.getConfigManager().getDifficultyConfig() == null) return;
        ConfigurationSection sec = plugin.getConfigManager().getDifficultyConfig().getConfigurationSection("difficulties." + difficulty.name());
        if (sec == null) return;

        this.reactionDelayTicks = sec.getInt("reaction-delay-ticks", getDefaultReactionDelay());
        this.aimAccuracy = sec.getDouble("aim-accuracy", getDefaultAimAccuracy());
        this.attackDelayTicks = sec.getInt("attack-delay-ticks", getDefaultAttackDelay());
        this.movementAggressiveness = sec.getDouble("movement-aggressiveness", getDefaultMovementAggressiveness());
        this.strafingIntensity = sec.getDouble("strafing-intensity", getDefaultStrafingIntensity());
        this.healingThreshold = sec.getDouble("healing-threshold", getDefaultHealingThreshold());
        this.itemSwitchDelayTicks = sec.getInt("item-switch-delay-ticks", getDefaultItemSwitchDelay());
        this.targetPredictionFactor = sec.getDouble("target-prediction-factor", getDefaultPredictionFactor());
        this.shieldBlockChance = sec.getDouble("shield-block-chance", getDefaultShieldBlockChance());
        this.crystalPlacementDelay = sec.getInt("crystal-placement-delay", getDefaultCrystalDelay());
        this.maceWindChargeChance = sec.getDouble("mace-wind-charge-chance", getDefaultMaceChargeChance());
    }

    private int getDefaultReactionDelay() {
        return switch (difficulty) {
            case EASY -> 10;
            case MEDIUM -> 5;
            case HARD -> 2;
        };
    }

    private double getDefaultAimAccuracy() {
        return switch (difficulty) {
            case EASY -> 0.65;
            case MEDIUM -> 0.85;
            case HARD -> 0.98;
        };
    }

    private int getDefaultAttackDelay() {
        return switch (difficulty) {
            case EASY -> 18;
            case MEDIUM -> 13;
            case HARD -> 10;
        };
    }

    private double getDefaultMovementAggressiveness() {
        return switch (difficulty) {
            case EASY -> 0.50;
            case MEDIUM -> 0.75;
            case HARD -> 0.95;
        };
    }

    private double getDefaultStrafingIntensity() {
        return switch (difficulty) {
            case EASY -> 0.30;
            case MEDIUM -> 0.65;
            case HARD -> 0.90;
        };
    }

    private double getDefaultHealingThreshold() {
        return switch (difficulty) {
            case EASY -> 0.35;
            case MEDIUM -> 0.50;
            case HARD -> 0.65;
        };
    }

    private int getDefaultItemSwitchDelay() {
        return switch (difficulty) {
            case EASY -> 12;
            case MEDIUM -> 6;
            case HARD -> 2;
        };
    }

    private double getDefaultPredictionFactor() {
        return switch (difficulty) {
            case EASY -> 0.15;
            case MEDIUM -> 0.60;
            case HARD -> 0.95;
        };
    }

    private double getDefaultShieldBlockChance() {
        return switch (difficulty) {
            case EASY -> 0.35;
            case MEDIUM -> 0.70;
            case HARD -> 0.92;
        };
    }

    private int getDefaultCrystalDelay() {
        return switch (difficulty) {
            case EASY -> 20;
            case MEDIUM -> 10;
            case HARD -> 4;
        };
    }

    private double getDefaultMaceChargeChance() {
        return switch (difficulty) {
            case EASY -> 0.30;
            case MEDIUM -> 0.65;
            case HARD -> 0.90;
        };
    }

    public Difficulty getDifficulty() {
        return difficulty;
    }

    public int getReactionDelayTicks() {
        return reactionDelayTicks;
    }

    public double getAimAccuracy() {
        return aimAccuracy;
    }

    public int getAttackDelayTicks() {
        return attackDelayTicks;
    }

    public double getMovementAggressiveness() {
        return movementAggressiveness;
    }

    public double getStrafingIntensity() {
        return strafingIntensity;
    }

    public double getHealingThreshold() {
        return healingThreshold;
    }

    public int getItemSwitchDelayTicks() {
        return itemSwitchDelayTicks;
    }

    public double getTargetPredictionFactor() {
        return targetPredictionFactor;
    }

    public double getShieldBlockChance() {
        return shieldBlockChance;
    }

    public int getCrystalPlacementDelay() {
        return crystalPlacementDelay;
    }

    public double getMaceWindChargeChance() {
        return maceWindChargeChance;
    }
}
