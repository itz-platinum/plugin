package com.velquora.aipvp.arena;

import com.velquora.aipvp.AiPvp;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks and guarantees complete cleanup of all session-spawned entities and projectiles.
 */
public class EntityTracker {

    private final AiPvp plugin;
    // Map: Session ID -> Set of tracked Entity UUIDs
    private final Map<UUID, Set<UUID>> sessionEntities = new ConcurrentHashMap<>();

    public EntityTracker(AiPvp plugin) {
        this.plugin = plugin;
    }

    /**
     * Registers a session for entity tracking.
     */
    public void registerSession(UUID sessionId) {
        sessionEntities.computeIfAbsent(sessionId, k -> ConcurrentHashMap.newKeySet());
    }

    /**
     * Tracks an entity (bot, crystal, projectile, arrow, etc.) associated with a session.
     */
    public void trackEntity(UUID sessionId, Entity entity) {
        if (sessionId == null || entity == null) return;
        Set<UUID> set = sessionEntities.computeIfAbsent(sessionId, k -> ConcurrentHashMap.newKeySet());
        set.add(entity.getUniqueId());
    }

    /**
     * Cleans up and removes all entities spawned during this session.
     */
    public int cleanupSessionEntities(UUID sessionId) {
        Set<UUID> entities = sessionEntities.remove(sessionId);
        if (entities == null || entities.isEmpty()) {
            return 0;
        }

        int removed = 0;
        for (UUID entityUuid : entities) {
            Entity entity = Bukkit.getEntity(entityUuid);
            if (entity != null && entity.isValid() && !entity.isDead()) {
                try {
                    entity.remove();
                    removed++;
                } catch (Exception ignored) {}
            }
        }

        if (plugin.getConfigManager().getConfig().getBoolean("debug.cleanup", false)) {
            plugin.getLogger().info("[AiPvP Cleanup] Removed " + removed + " session-owned entities for session " + sessionId);
        }
        return removed;
    }

    /**
     * Removes all tracked entities across all sessions (used on plugin disable / reload).
     */
    public void cleanupAll() {
        for (UUID sessionId : new HashSet<>(sessionEntities.keySet())) {
            cleanupSessionEntities(sessionId);
        }
    }
}
