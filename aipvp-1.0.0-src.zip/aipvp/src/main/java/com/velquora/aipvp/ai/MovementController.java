package com.velquora.aipvp.ai;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Governs tactical movement: sprint-jumping, strafing, tactical retreats, and terrain navigation.
 */
public class MovementController {

    private final DifficultyController difficultyController;
    private int strafeDirection = 1; // 1 = right, -1 = left
    private int strafeTimer = 0;
    private int jumpCooldown = 0;

    public MovementController(DifficultyController difficultyController) {
        this.difficultyController = difficultyController;
    }

    /**
     * Executes movement update for current tick.
     */
    public void updateMovement(LivingEntity bot, Location targetLoc, double idealDistance, boolean isRetreating) {
        if (bot == null || !bot.isValid() || targetLoc == null) return;

        Location botLoc = bot.getLocation();
        double distance = botLoc.distance(targetLoc);

        // Update Mob pathfinder navigation if supported
        if (bot instanceof Mob mob) {
            if (isRetreating) {
                Vector away = botLoc.toVector().subtract(targetLoc.toVector()).normalize().multiply(12.0);
                Location retreatTarget = botLoc.clone().add(away);
                mob.getPathfinder().moveTo(retreatTarget, 1.25);
            } else {
                mob.getPathfinder().moveTo(targetLoc, 1.15 * difficultyController.getMovementAggressiveness());
            }
        }

        // Tactical Strafing
        updateStrafeTimer();
        Vector movementImpulse = new Vector(0, 0, 0);

        Vector toTarget = targetLoc.toVector().subtract(botLoc.toVector());
        toTarget.setY(0);
        if (toTarget.lengthSquared() > 0.01) {
            toTarget.normalize();
        }

        if (isRetreating) {
            // Push backward
            movementImpulse.add(toTarget.clone().multiply(-0.25));
        } else if (distance > idealDistance) {
            // Push forward
            movementImpulse.add(toTarget.clone().multiply(0.28 * difficultyController.getMovementAggressiveness()));
        } else if (distance < idealDistance - 1.0) {
            // Too close, push slightly back to maintain spacing
            movementImpulse.add(toTarget.clone().multiply(-0.15));
        }

        // Side-strafe calculation (perpendicular vector)
        double strafeIntensity = difficultyController.getStrafingIntensity();
        if (strafeIntensity > 0.1 && distance < 12.0) {
            Vector strafeVec = new Vector(-toTarget.getZ(), 0, toTarget.getX()).multiply(strafeDirection * strafeIntensity * 0.22);
            movementImpulse.add(strafeVec);
        }

        // Auto-Jump & Sprint assistance
        if (bot.isOnGround() && jumpCooldown <= 0) {
            boolean shouldJump = false;
            // Obstacle in front?
            Location ahead = botLoc.clone().add(botLoc.getDirection().multiply(1.0));
            Block blockAhead = ahead.getBlock();
            if (blockAhead.getType().isSolid()) {
                shouldJump = true;
            } else if (!isRetreating && distance > 3.0 && distance < 15.0 && ThreadLocalRandom.current().nextDouble() < (0.25 * difficultyController.getMovementAggressiveness())) {
                // Sprint jump momentum
                shouldJump = true;
            }

            if (shouldJump) {
                movementImpulse.setY(0.42); // standard Minecraft jump velocity
                jumpCooldown = 15;
            }
        } else if (jumpCooldown > 0) {
            jumpCooldown--;
        }

        // Apply additional velocity if not stationary
        if (movementImpulse.lengthSquared() > 0.001) {
            Vector currentVel = bot.getVelocity();
            Vector blended = currentVel.clone().multiply(0.4).add(movementImpulse.multiply(0.6));
            if (bot.isOnGround() && blended.getY() > 0.42) {
                blended.setY(0.42);
            }
            bot.setVelocity(blended);
        }
    }

    private void updateStrafeTimer() {
        strafeTimer++;
        if (strafeTimer > (30 + ThreadLocalRandom.current().nextInt(25))) {
            strafeDirection = -strafeDirection;
            strafeTimer = 0;
        }
    }

    public void applyKnockbackResistance(LivingEntity bot) {
        // Keeps bot responsive
    }
}
