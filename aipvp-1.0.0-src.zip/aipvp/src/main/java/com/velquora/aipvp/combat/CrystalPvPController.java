package com.velquora.aipvp.combat;

import com.velquora.aipvp.AiPvp;
import com.velquora.aipvp.ai.*;
import com.velquora.aipvp.bot.BotEntity;
import com.velquora.aipvp.bot.BotResources;
import com.velquora.aipvp.gemini.StrategicPlan;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/**
 * Controller for Crystal PvP mode: Obsidian placement, End Crystal deployment, damage safety validation, and Totem cycling.
 */
public class CrystalPvPController {

    private final AiPvp plugin;
    private final UUID sessionId;
    private final AimController aimController;
    private final MovementController movementController;
    private final CombatController combatController;
    private final TargetPrediction targetPrediction;
    private final PotionController potionController;
    private final DifficultyController difficultyController;

    private int crystalActionTimer = 0;

    public CrystalPvPController(AiPvp plugin,
                                UUID sessionId,
                                AimController aimController,
                                MovementController movementController,
                                CombatController combatController,
                                TargetPrediction targetPrediction,
                                PotionController potionController,
                                DifficultyController difficultyController) {
        this.plugin = plugin;
        this.sessionId = sessionId;
        this.aimController = aimController;
        this.movementController = movementController;
        this.combatController = combatController;
        this.targetPrediction = targetPrediction;
        this.potionController = potionController;
        this.difficultyController = difficultyController;
    }

    public void tick(BotEntity botEntity, Player target, StrategicPlan strategicPlan) {
        if (botEntity == null || !botEntity.isAlive() || target == null || !target.isOnline()) return;
        LivingEntity bot = botEntity.getEntity();
        BotResources resources = botEntity.getResources();

        combatController.tick();
        potionController.tick();
        if (crystalActionTimer > 0) crystalActionTimer--;

        double distance = bot.getLocation().distance(target.getLocation());
        boolean isLowHealth = (bot.getHealth() / 20.0) <= difficultyController.getHealingThreshold();

        // 1. Maintain Totem in Offhand if available
        ensureTotem(botEntity);

        // 2. Health & Healing
        if (isLowHealth || strategicPlan == StrategicPlan.HEAL) {
            potionController.checkHealing(botEntity);
        }

        // 3. Aim towards predicted target
        Location predictedTarget = targetPrediction.predictPosition(target, 4.0, difficultyController.getTargetPredictionFactor());
        aimController.lookAt(bot, predictedTarget.clone().add(0, 1.0, 0));

        // 4. Crystal Combat Loop (Controlled by safety threshold)
        if (crystalActionTimer <= 0) {
            boolean acted = attemptCrystalCombo(botEntity, target);
            if (acted) {
                crystalActionTimer = difficultyController.getCrystalPlacementDelay();
            }
        }

        // 5. Sword melee if in close range
        if (distance <= 3.5) {
            combatController.performMeleeAttack(bot, target);
        }

        // 6. Strategic spacing: maintain 4.0 - 5.5 blocks spacing for optimal crystal detonation
        boolean retreat = (strategicPlan == StrategicPlan.RETREAT || isLowHealth);
        movementController.updateMovement(bot, target.getLocation(), 4.8, retreat);
    }

    private boolean attemptCrystalCombo(BotEntity botEntity, Player target) {
        LivingEntity bot = botEntity.getEntity();
        BotResources resources = botEntity.getResources();

        Location playerLoc = target.getLocation();
        Location botLoc = bot.getLocation();
        double maxAcceptableSelfDamage = plugin.getConfigManager().getConfig().getDouble("combat.crystal-self-damage-threshold", 12.0);

        // 1. Check for nearby existing End Crystals to detonate first
        for (Entity entity : bot.getWorld().getNearbyEntities(playerLoc, 6.0, 6.0, 6.0)) {
            if (entity instanceof EnderCrystal crystal) {
                // Safety evaluation: will this blow up the bot more than the player?
                if (WorldPerception.isCrystalTacticallySafe(crystal.getLocation(), botLoc, playerLoc, maxAcceptableSelfDamage)) {
                    bot.getWorld().playSound(crystal.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
                    crystal.damage(10.0, bot);
                    return true;
                }
            }
        }

        // 2. Check consumable stock
        if (resources.getObsidian() <= 0 || resources.getEndCrystals() <= 0) {
            return false;
        }

        // 3. Find candidate ground block near player
        Block targetGround = playerLoc.getBlock().getRelative(BlockFace.DOWN);
        Block placeBase = null;

        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                Block b = targetGround.getRelative(dx, 0, dz);
                Block above = b.getRelative(BlockFace.UP);
                Block above2 = above.getRelative(BlockFace.UP);

                if (b.getType().isSolid() && above.getType().isAir() && above2.getType().isAir()) {
                    Location candidateCrystalLoc = above.getLocation().add(0.5, 1.0, 0.5);
                    // Verify tactical safety before placement
                    if (WorldPerception.isCrystalTacticallySafe(candidateCrystalLoc, botLoc, playerLoc, maxAcceptableSelfDamage)) {
                        placeBase = b;
                        break;
                    }
                }
            }
            if (placeBase != null) break;
        }

        if (placeBase != null) {
            Block obbyBlock = placeBase.getRelative(BlockFace.UP);
            if (obbyBlock.getType().isAir() && resources.useObsidian() && resources.useEndCrystal()) {
                // PART 2: Record PRE-modification state for transactional rollback
                plugin.getArenaManager().getRollbackManager().recordPreModification(sessionId, obbyBlock);

                obbyBlock.setType(Material.OBSIDIAN);
                bot.getWorld().playSound(obbyBlock.getLocation(), Sound.BLOCK_STONE_PLACE, 1.0f, 1.0f);

                // Place End Crystal on top
                Location crystalLoc = obbyBlock.getLocation().add(0.5, 1.0, 0.5);
                EnderCrystal crystal = bot.getWorld().spawn(crystalLoc, EnderCrystal.class);
                crystal.setShowingBottom(true);

                // PART 3: Track crystal entity for guaranteed cleanup
                plugin.getArenaManager().getEntityTracker().trackEntity(sessionId, crystal);
                return true;
            }
        }

        return false;
    }

    private void ensureTotem(BotEntity botEntity) {
        LivingEntity bot = botEntity.getEntity();
        EntityEquipment eq = bot.getEquipment();
        if (eq == null) return;

        if (eq.getItemInOffHand().getType() != Material.TOTEM_OF_UNDYING) {
            if (botEntity.getResources().useTotem()) {
                eq.setItemInOffHand(new ItemStack(Material.TOTEM_OF_UNDYING));
            }
        }
    }
}
