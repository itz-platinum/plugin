package com.velquora.aipvp.arena;

import com.velquora.aipvp.AiPvp;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Transaction-style rollback engine for all blocks modified during active PvP sessions.
 * Preserves the true pre-session original state before any modification occurs.
 */
public class ArenaRollbackManager {

    private final AiPvp plugin;

    /**
     * Immutable spatial coordinate key for tracking block locations.
     */
    public record BlockKey(String worldName, int x, int y, int z) {
        public static BlockKey from(Block block) {
            return new BlockKey(block.getWorld().getName(), block.getX(), block.getY(), block.getZ());
        }

        public static BlockKey from(Location loc) {
            return new BlockKey(loc.getWorld().getName(), loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
        }
    }

    /**
     * Snapshot record of the original pre-modification block data.
     */
    public record BlockSnapshot(BlockKey key, BlockData originalData, long timestamp) {}

    // Map: Session UUID -> Map<BlockKey, BlockSnapshot>
    // Keyed by spatial position so only the FIRST pre-modification state is kept.
    private final Map<UUID, Map<BlockKey, BlockSnapshot>> sessionRollbacks = new ConcurrentHashMap<>();

    public ArenaRollbackManager(AiPvp plugin) {
        this.plugin = plugin;
    }

    /**
     * Registers a session for block tracking.
     */
    public void registerSession(UUID sessionId) {
        sessionRollbacks.computeIfAbsent(sessionId, k -> new ConcurrentHashMap<>());
    }

    /**
     * Records the state of a block BEFORE modification.
     * Guarantees that only the earliest original block state is stored.
     */
    public void recordPreModification(UUID sessionId, Block block) {
        if (sessionId == null || block == null || block.getWorld() == null) return;

        Map<BlockKey, BlockSnapshot> map = sessionRollbacks.get(sessionId);
        if (map == null) return;

        BlockKey key = BlockKey.from(block);
        // putIfAbsent ensures that if the block is changed multiple times, the initial original state is preserved!
        map.putIfAbsent(key, new BlockSnapshot(key, block.getBlockData().clone(), System.currentTimeMillis()));
    }

    /**
     * Records multiple blocks (e.g. from an explosion blockList) before they are destroyed.
     */
    public void recordPreModifications(UUID sessionId, Collection<Block> blocks) {
        if (sessionId == null || blocks == null) return;
        for (Block b : blocks) {
            recordPreModification(sessionId, b);
        }
    }

    /**
     * Restores all modified blocks in the arena for the given session.
     */
    public int rollbackSession(UUID sessionId) {
        Map<BlockKey, BlockSnapshot> map = sessionRollbacks.remove(sessionId);
        if (map == null || map.isEmpty()) {
            return 0;
        }

        int count = 0;
        for (BlockSnapshot snapshot : map.values()) {
            BlockKey key = snapshot.key();
            World world = Bukkit.getWorld(key.worldName());
            if (world == null) continue;

            int chunkX = key.x() >> 4;
            int chunkZ = key.z() >> 4;

            boolean wasLoaded = world.isChunkLoaded(chunkX, chunkZ);
            if (!wasLoaded) {
                // Safely load chunk temporarily without generating terrain
                world.getChunkAt(chunkX, chunkZ);
            }

            try {
                Block block = world.getBlockAt(key.x(), key.y(), key.z());
                block.setBlockData(snapshot.originalData(), false); // false = no physics to prevent side-effects
                count++;
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Failed to restore block at " + key + ": " + e.getMessage());
            }
        }

        if (plugin.getConfigManager().getConfig().getBoolean("debug.cleanup", false)) {
            plugin.getLogger().info("[AiPvP Rollback] Rolled back " + count + " blocks for session " + sessionId);
        }
        return count;
    }

    /**
     * Cleanly restores all pending sessions during server shutdown or plugin disable.
     */
    public void rollbackAll() {
        for (UUID sessionId : new HashSet<>(sessionRollbacks.keySet())) {
            rollbackSession(sessionId);
        }
    }
}
