package com.velquora.aipvp.arena;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Represents a dedicated, isolated duel arena with strict spatial boundaries.
 */
public class Arena {

    public enum Status {
        AVAILABLE,
        IN_USE,
        DISABLED
    }

    private final String id;
    private String displayName;
    private String worldName;
    private Location playerSpawn;
    private Location botSpawn;
    private double radius;
    private boolean enabled;
    private List<String> allowedModes = new ArrayList<>();
    private Status status = Status.AVAILABLE;
    private UUID currentSessionId = null;

    public Arena(String id, String displayName, String worldName, Location playerSpawn, Location botSpawn, double radius) {
        this.id = id;
        this.displayName = displayName;
        this.worldName = worldName;
        this.playerSpawn = playerSpawn;
        this.botSpawn = botSpawn;
        this.radius = Math.max(10.0, radius);
        this.enabled = true;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName != null ? displayName : id;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getWorldName() {
        return worldName;
    }

    public void setWorldName(String worldName) {
        this.worldName = worldName;
    }

    public World getWorld() {
        return worldName != null ? Bukkit.getWorld(worldName) : null;
    }

    public Location getPlayerSpawn() {
        return playerSpawn != null ? playerSpawn.clone() : null;
    }

    public void setPlayerSpawn(Location playerSpawn) {
        this.playerSpawn = playerSpawn;
        if (playerSpawn != null && playerSpawn.getWorld() != null) {
            this.worldName = playerSpawn.getWorld().getName();
        }
    }

    public Location getBotSpawn() {
        return botSpawn != null ? botSpawn.clone() : null;
    }

    public void setBotSpawn(Location botSpawn) {
        this.botSpawn = botSpawn;
        if (botSpawn != null && botSpawn.getWorld() != null) {
            this.worldName = botSpawn.getWorld().getName();
        }
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = Math.max(10.0, radius);
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        if (!enabled && status == Status.AVAILABLE) {
            this.status = Status.DISABLED;
        } else if (enabled && status == Status.DISABLED) {
            this.status = Status.AVAILABLE;
        }
    }

    public List<String> getAllowedModes() {
        return allowedModes;
    }

    public void setAllowedModes(List<String> allowedModes) {
        this.allowedModes = allowedModes != null ? allowedModes : new ArrayList<>();
    }

    public boolean isModeAllowed(String modeName) {
        if (allowedModes == null || allowedModes.isEmpty()) return true;
        for (String m : allowedModes) {
            if (m.equalsIgnoreCase(modeName)) return true;
        }
        return false;
    }

    public Status getStatus() {
        return status;
    }

    public synchronized boolean acquire(UUID sessionId) {
        if (!enabled || status != Status.AVAILABLE || getWorld() == null) {
            return false;
        }
        this.status = Status.IN_USE;
        this.currentSessionId = sessionId;
        return true;
    }

    public synchronized void release() {
        this.currentSessionId = null;
        this.status = enabled ? Status.AVAILABLE : Status.DISABLED;
    }

    public UUID getCurrentSessionId() {
        return currentSessionId;
    }

    /**
     * Gets the geometric center point between player spawn and bot spawn, or player spawn.
     */
    public Location getCenterLocation() {
        if (playerSpawn != null && botSpawn != null && playerSpawn.getWorld().equals(botSpawn.getWorld())) {
            return new Location(
                    playerSpawn.getWorld(),
                    (playerSpawn.getX() + botSpawn.getX()) / 2.0,
                    (playerSpawn.getY() + botSpawn.getY()) / 2.0,
                    (playerSpawn.getZ() + botSpawn.getZ()) / 2.0
            );
        }
        return playerSpawn != null ? playerSpawn.clone() : (botSpawn != null ? botSpawn.clone() : null);
    }

    /**
     * Checks if a location is strictly within the arena radius.
     */
    public boolean isInside(Location loc) {
        if (loc == null || loc.getWorld() == null) return false;
        Location center = getCenterLocation();
        if (center == null || !loc.getWorld().equals(center.getWorld())) return false;

        double dx = loc.getX() - center.getX();
        double dz = loc.getZ() - center.getZ();
        return (dx * dx + dz * dz) <= (radius * radius);
    }

    /**
     * Calculates distance from center in the horizontal XZ plane.
     */
    public double getHorizontalDistanceFromCenter(Location loc) {
        Location center = getCenterLocation();
        if (center == null || loc == null || !loc.getWorld().equals(center.getWorld())) return Double.MAX_VALUE;
        double dx = loc.getX() - center.getX();
        double dz = loc.getZ() - center.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    /**
     * Enforces arena boundary safely by either gentle velocity recoil (soft) or safe perimeter relocation (hard).
     */
    public void enforceBoundary(Entity entity, String mode) {
        if (entity == null || !entity.isValid()) return;
        Location loc = entity.getLocation();
        Location center = getCenterLocation();
        if (center == null || loc.getWorld() == null || !loc.getWorld().equals(center.getWorld())) return;

        double dist = getHorizontalDistanceFromCenter(loc);
        if (dist > radius) {
            Vector toCenter = center.toVector().subtract(loc.toVector());
            toCenter.setY(0);
            if (toCenter.lengthSquared() > 0.001) {
                toCenter.normalize();
            }

            if ("hard".equalsIgnoreCase(mode)) {
                // Hard mode: Reposition entity safely inside perimeter
                Location safeLoc = center.clone().add(toCenter.clone().multiply(-radius * 0.85));
                safeLoc.setY(loc.getY());
                safeLoc.setYaw(loc.getYaw());
                safeLoc.setPitch(loc.getPitch());
                entity.teleport(safeLoc);
            } else {
                // Soft mode: Gentle repulsive impulse inward
                Vector vel = toCenter.multiply(0.45);
                vel.setY(0.1);
                entity.setVelocity(vel);
            }
        }
    }
}
