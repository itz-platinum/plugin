package com.velquora.aipvp.kit;

import com.velquora.aipvp.AiPvp;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

import java.util.*;

/**
 * Loads, parses, and distributes combat kits for Normal, Crystal, and Mace PvP modes.
 */
public class KitManager {

    private final AiPvp plugin;

    public enum Mode {
        NORMAL_PVP("Normal PvP", Material.GRASS_BLOCK),
        CRYSTAL_PVP("Crystal PvP", Material.END_CRYSTAL),
        MACE_PVP("Mace PvP", Material.MACE);

        private final String displayName;
        private final Material icon;

        Mode(String displayName, Material icon) {
            this.displayName = displayName;
            this.icon = icon;
        }

        public String getDisplayName() {
            return displayName;
        }

        public Material getIcon() {
            return icon;
        }
    }

    public KitManager(AiPvp plugin) {
        this.plugin = plugin;
    }

    /**
     * Equips a player with the complete specified kit.
     */
    public void equipPlayer(Player player, Mode mode) {
        if (player == null) return;
        player.getInventory().clear();

        ConfigurationSection kitSec = getKitSection(mode);
        if (kitSec == null) {
            giveFallbackPlayerKit(player, mode);
            return;
        }

        // Armor
        player.getInventory().setHelmet(buildItem(kitSec.getConfigurationSection("helmet")));
        player.getInventory().setChestplate(buildItem(kitSec.getConfigurationSection("chestplate")));
        player.getInventory().setLeggings(buildItem(kitSec.getConfigurationSection("leggings")));
        player.getInventory().setBoots(buildItem(kitSec.getConfigurationSection("boots")));
        player.getInventory().setItemInOffHand(buildItem(kitSec.getConfigurationSection("offhand")));

        // Inventory slots
        List<Map<?, ?>> items = kitSec.getMapList("inventory");
        for (Map<?, ?> itemMap : items) {
            try {
                int slot = itemMap.containsKey("slot") ? ((Number) itemMap.get("slot")).intValue() : -1;
                ItemStack stack = parseItemFromMap(itemMap);
                if (stack != null && slot >= 0 && slot < 36) {
                    player.getInventory().setItem(slot, stack);
                }
            } catch (Exception e) {
                plugin.getLogger().warning("Error parsing item in kit " + mode.name() + ": " + e.getMessage());
            }
        }
        player.updateInventory();
    }

    /**
     * Equips a bot entity with appropriate armor and main weapon from the kit.
     */
    public void equipBot(LivingEntity entity, Mode mode) {
        if (entity == null) return;
        EntityEquipment eq = entity.getEquipment();
        if (eq == null) return;

        ConfigurationSection kitSec = getKitSection(mode);
        if (kitSec == null) {
            giveFallbackBotKit(entity, mode);
            return;
        }

        ItemStack helm = buildItem(kitSec.getConfigurationSection("helmet"));
        ItemStack chest = buildItem(kitSec.getConfigurationSection("chestplate"));
        ItemStack legs = buildItem(kitSec.getConfigurationSection("leggings"));
        ItemStack boots = buildItem(kitSec.getConfigurationSection("boots"));
        ItemStack offhand = buildItem(kitSec.getConfigurationSection("offhand"));

        if (helm != null) eq.setHelmet(helm);
        if (chest != null) eq.setChestplate(chest);
        if (legs != null) eq.setLeggings(legs);
        if (boots != null) eq.setBoots(boots);
        if (offhand != null) eq.setItemInOffHand(offhand);

        // Find primary weapon from slot 0
        List<Map<?, ?>> items = kitSec.getMapList("inventory");
        ItemStack weapon = null;
        for (Map<?, ?> itemMap : items) {
            int slot = itemMap.containsKey("slot") ? ((Number) itemMap.get("slot")).intValue() : -1;
            if (slot == 0) {
                weapon = parseItemFromMap(itemMap);
                break;
            }
        }

        if (weapon != null) {
            eq.setItemInMainHand(weapon);
        } else {
            eq.setItemInMainHand(new ItemStack(mode == Mode.MACE_PVP ? Material.MACE : Material.NETHERITE_SWORD));
        }

        // Drop chances = 0 so bots don't drop items
        eq.setHelmetDropChance(0.0f);
        eq.setChestplateDropChance(0.0f);
        eq.setLeggingsDropChance(0.0f);
        eq.setBootsDropChance(0.0f);
        eq.setItemInMainHandDropChance(0.0f);
        eq.setItemInOffHandDropChance(0.0f);
    }

    private ConfigurationSection getKitSection(Mode mode) {
        if (plugin.getConfigManager().getKitsConfig() == null) return null;
        return plugin.getConfigManager().getKitsConfig().getConfigurationSection("kits." + mode.name());
    }

    private ItemStack buildItem(ConfigurationSection sec) {
        if (sec == null) return null;
        String matName = sec.getString("material");
        if (matName == null) return null;

        Material mat = Material.matchMaterial(matName);
        if (mat == null) return null;

        int amount = sec.getInt("amount", 1);
        ItemStack stack = new ItemStack(mat, Math.max(1, amount));
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            if (sec.getBoolean("unbreakable", false)) {
                meta.setUnbreakable(true);
            }
            if (sec.contains("display-name")) {
                meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', sec.getString("display-name")));
            }
            ConfigurationSection enchants = sec.getConfigurationSection("enchantments");
            if (enchants != null) {
                for (String encKey : enchants.getKeys(false)) {
                    Enchantment enc = matchEnchantment(encKey);
                    if (enc != null) {
                        int level = enchants.getInt(encKey, 1);
                        meta.addEnchant(enc, level, true);
                    }
                }
            }
            applyPotionMeta(meta, sec.getString("potion-type"));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    @SuppressWarnings("unchecked")
    private ItemStack parseItemFromMap(Map<?, ?> map) {
        String matName = Objects.toString(map.get("material"), null);
        if (matName == null) return null;
        Material mat = Material.matchMaterial(matName);
        if (mat == null) return null;

        int amount = map.containsKey("amount") ? ((Number) map.get("amount")).intValue() : 1;
        ItemStack stack = new ItemStack(mat, Math.max(1, amount));
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            if (Boolean.TRUE.equals(map.get("unbreakable"))) {
                meta.setUnbreakable(true);
            }
            if (map.containsKey("display-name")) {
                meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', map.get("display-name").toString()));
            }
            if (map.containsKey("enchantments") && map.get("enchantments") instanceof Map) {
                Map<?, ?> enchants = (Map<?, ?>) map.get("enchantments");
                for (Map.Entry<?, ?> entry : enchants.entrySet()) {
                    Enchantment enc = matchEnchantment(Objects.toString(entry.getKey(), ""));
                    if (enc != null) {
                        int level = entry.getValue() instanceof Number ? ((Number) entry.getValue()).intValue() : 1;
                        meta.addEnchant(enc, level, true);
                    }
                }
            }
            if (map.containsKey("potion-type")) {
                applyPotionMeta(meta, Objects.toString(map.get("potion-type"), ""));
            }
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private void applyPotionMeta(ItemMeta meta, String potionTypeName) {
        if (meta instanceof PotionMeta potionMeta && potionTypeName != null && !potionTypeName.isEmpty()) {
            try {
                PotionType pt = PotionType.valueOf(potionTypeName.toUpperCase());
                potionMeta.setBasePotionType(pt);
            } catch (Exception ignored) {
            }
        }
    }

    private Enchantment matchEnchantment(String name) {
        if (name == null || name.isEmpty()) return null;
        String clean = name.toLowerCase().replace("minecraft:", "").replace("-", "_").trim();
        NamespacedKey key = NamespacedKey.minecraft(clean);
        Enchantment enc = Enchantment.getByKey(key);
        if (enc != null) return enc;

        // Legacy/Common names mapping
        return switch (clean) {
            case "protection" -> Enchantment.PROTECTION;
            case "sharpness" -> Enchantment.SHARPNESS;
            case "unbreaking" -> Enchantment.UNBREAKING;
            case "efficiency" -> Enchantment.EFFICIENCY;
            case "feather_falling" -> Enchantment.FEATHER_FALLING;
            case "blast_protection" -> Enchantment.BLAST_PROTECTION;
            case "power" -> Enchantment.POWER;
            case "infinity" -> Enchantment.INFINITY;
            case "density" -> Enchantment.DENSITY;
            case "breach" -> Enchantment.BREACH;
            case "wind_burst" -> Enchantment.WIND_BURST;
            default -> null;
        };
    }

    private void giveFallbackPlayerKit(Player player, Mode mode) {
        player.getInventory().setHelmet(new ItemStack(Material.NETHERITE_HELMET));
        player.getInventory().setChestplate(new ItemStack(Material.NETHERITE_CHESTPLATE));
        player.getInventory().setLeggings(new ItemStack(Material.NETHERITE_LEGGINGS));
        player.getInventory().setBoots(new ItemStack(Material.NETHERITE_BOOTS));

        if (mode == Mode.MACE_PVP) {
            player.getInventory().setItem(0, new ItemStack(Material.MACE));
            player.getInventory().setItem(1, new ItemStack(Material.NETHERITE_SWORD));
            player.getInventory().setItem(2, new ItemStack(Material.WIND_CHARGE, 32));
        } else if (mode == Mode.CRYSTAL_PVP) {
            player.getInventory().setItem(0, new ItemStack(Material.NETHERITE_SWORD));
            player.getInventory().setItem(1, new ItemStack(Material.END_CRYSTAL, 64));
            player.getInventory().setItem(2, new ItemStack(Material.OBSIDIAN, 64));
            player.getInventory().setItem(3, new ItemStack(Material.NETHERITE_PICKAXE));
        } else {
            player.getInventory().setItem(0, new ItemStack(Material.NETHERITE_SWORD));
            player.getInventory().setItem(1, new ItemStack(Material.NETHERITE_AXE));
            player.getInventory().setItem(2, new ItemStack(Material.BOW));
            player.getInventory().setItem(9, new ItemStack(Material.ARROW, 64));
        }
        player.getInventory().setItem(3, new ItemStack(Material.GOLDEN_APPLE, 16));
        player.getInventory().setItemInOffHand(new ItemStack(Material.SHIELD));
    }

    private void giveFallbackBotKit(LivingEntity entity, Mode mode) {
        EntityEquipment eq = entity.getEquipment();
        if (eq == null) return;
        eq.setHelmet(new ItemStack(Material.NETHERITE_HELMET));
        eq.setChestplate(new ItemStack(Material.NETHERITE_CHESTPLATE));
        eq.setLeggings(new ItemStack(Material.NETHERITE_LEGGINGS));
        eq.setBoots(new ItemStack(Material.NETHERITE_BOOTS));
        eq.setItemInMainHand(new ItemStack(mode == Mode.MACE_PVP ? Material.MACE : Material.NETHERITE_SWORD));
        eq.setItemInOffHand(new ItemStack(mode == Mode.CRYSTAL_PVP ? Material.TOTEM_OF_UNDYING : Material.SHIELD));
    }
}
