package com.velquora.aipvp.combat;

import com.velquora.aipvp.ai.DifficultyController;
import com.velquora.aipvp.bot.BotEntity;
import com.velquora.aipvp.bot.BotResources;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.LivingEntity;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Handles potion splashing, golden apple consumption, and resource-bounded healing.
 */
public class PotionController {

    private final DifficultyController difficultyController;
    private int potionCooldownTicks = 0;
    private int gappleCooldownTicks = 0;

    public PotionController(DifficultyController difficultyController) {
        this.difficultyController = difficultyController;
    }

    public void tick() {
        if (potionCooldownTicks > 0) potionCooldownTicks--;
        if (gappleCooldownTicks > 0) gappleCooldownTicks--;
    }

    /**
     * Checks if the bot needs and can use a healing item from its tracked inventory.
     */
    public boolean checkHealing(BotEntity botEntity) {
        if (botEntity == null || !botEntity.isAlive()) return false;
        LivingEntity bot = botEntity.getEntity();
        BotResources resources = botEntity.getResources();

        AttributeInstance maxHealthAttr = bot.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        double maxHealth = (maxHealthAttr != null) ? maxHealthAttr.getValue() : 20.0;
        double currentHealth = bot.getHealth();
        double ratio = currentHealth / maxHealth;

        if (ratio <= difficultyController.getHealingThreshold()) {
            if (potionCooldownTicks <= 0 && resources.useSplashPotion()) {
                splashHealingPotion(bot);
                return true;
            } else if (gappleCooldownTicks <= 0 && resources.useGoldenApple()) {
                eatGoldenApple(bot);
                return true;
            }
        }
        return false;
    }

    public void splashHealingPotion(LivingEntity bot) {
        if (bot == null) return;
        potionCooldownTicks = 30;

        Location loc = bot.getLocation();
        loc.getWorld().playSound(loc, Sound.ENTITY_SPLASH_POTION_BREAK, 1.0f, 1.0f);
        loc.getWorld().spawnParticle(Particle.POTION, loc, 25, 0.5, 0.5, 0.5);

        // Apply direct healing (Instant Health II = 8 HP)
        double newHealth = Math.min(20.0, bot.getHealth() + 8.0);
        bot.setHealth(newHealth);
    }

    public void eatGoldenApple(LivingEntity bot) {
        if (bot == null) return;
        gappleCooldownTicks = 100; // 5 seconds

        Location loc = bot.getLocation();
        loc.getWorld().playSound(loc, Sound.ENTITY_PLAYER_BURP, 1.0f, 1.0f);

        // Regeneration II for 5 seconds + Absorption for 2 minutes
        bot.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1, false, true));
        bot.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 2400, 0, false, true));
    }
}
