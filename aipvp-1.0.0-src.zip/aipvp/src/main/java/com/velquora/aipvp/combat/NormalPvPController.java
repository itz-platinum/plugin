package com.velquora.aipvp.combat;

import com.velquora.aipvp.AiPvp;
import com.velquora.aipvp.ai.*;
import com.velquora.aipvp.bot.BotEntity;
import com.velquora.aipvp.bot.BotResources;
import com.velquora.aipvp.gemini.StrategicPlan;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.UUID;

/**
 * Controller for Normal PvP mode: Sword/Axe combat, shield mechanics, bow shooting, and spacing.
 * Dynamically reacts to Gemini strategic postures and tracks arrow & consumable usage.
 */
public class NormalPvPController {

    private final AiPvp plugin;
    private final UUID sessionId;
    private final AimController aimController;
    private final MovementController movementController;
    private final CombatController combatController;
    private final TargetPrediction targetPrediction;
    private final PotionController potionController;
    private final ShieldController shieldController;
    private final DifficultyController difficultyController;

    private int bowChargeTicks = 0;
    private int bowCooldown = 0;

    public NormalPvPController(AiPvp plugin,
                               UUID sessionId,
                               AimController aimController,
                               MovementController movementController,
                               CombatController combatController,
                               TargetPrediction targetPrediction,
                               PotionController potionController,
                               ShieldController shieldController,
                               DifficultyController difficultyController) {
        this.plugin = plugin;
        this.sessionId = sessionId;
        this.aimController = aimController;
        this.movementController = movementController;
        this.combatController = combatController;
        this.targetPrediction = targetPrediction;
        this.potionController = potionController;
        this.shieldController = shieldController;
        this.difficultyController = difficultyController;
    }

    public void tick(BotEntity botEntity, Player target, StrategicPlan strategicPlan) {
        if (botEntity == null || !botEntity.isAlive() || target == null || !target.isOnline()) return;
        LivingEntity bot = botEntity.getEntity();
        BotResources resources = botEntity.getResources();

        combatController.tick();
        potionController.tick();
        shieldController.tick(bot);
        if (bowCooldown > 0) bowCooldown--;

        double distance = bot.getLocation().distance(target.getLocation());
        boolean isLowHealth = (bot.getHealth() / 20.0) <= difficultyController.getHealingThreshold();

        // 1. Aim towards predicted target location
        Location aimTarget = targetPrediction.predictPosition(target, distance * 0.75, difficultyController.getTargetPredictionFactor());
        aimController.lookAt(bot, aimTarget.clone().add(0, 1.2, 0));

        // 2. Health & Potion check (or strategic HEAL command)
        if (isLowHealth || strategicPlan == StrategicPlan.HEAL) {
            potionController.checkHealing(botEntity);
        }

        // 3. Tactical posture resolution
        EntityEquipment eq = bot.getEquipment();

        if (strategicPlan == StrategicPlan.BREAK_SHIELD || target.isBlocking()) {
            // Prioritize axe strike to disable player shield
            if (eq != null && eq.getItemInMainHand().getType() != Material.NETHERITE_AXE && combatController.canSwitchItem()) {
                eq.setItemInMainHand(new ItemStack(Material.NETHERITE_AXE));
                combatController.triggerItemSwitchCooldown();
            }
        } else if (strategicPlan == StrategicPlan.BOW_PRESSURE && distance > 8.0 && resources.getArrows() > 0) {
            handleBowCombat(botEntity, target, eq);
            movementController.updateMovement(bot, target.getLocation(), 10.0, false);
            return;
        } else {
            // Standard sword melee
            if (eq != null && eq.getItemInMainHand().getType() != Material.NETHERITE_SWORD && combatController.canSwitchItem()) {
                eq.setItemInMainHand(new ItemStack(Material.NETHERITE_SWORD));
                combatController.triggerItemSwitchCooldown();
            }
        }

        // Shield defense if incoming threat
        shieldController.considerBlocking(bot, distance);

        // Execute melee swing if in reach
        if (distance <= 3.5) {
            combatController.performMeleeAttack(bot, target);
        }

        // Movement spacing
        boolean shouldRetreat = (strategicPlan == StrategicPlan.RETREAT || isLowHealth);
        movementController.updateMovement(bot, target.getLocation(), 2.4, shouldRetreat);
    }

    private void handleBowCombat(BotEntity botEntity, Player target, EntityEquipment eq) {
        if (eq == null) return;
        LivingEntity bot = botEntity.getEntity();
        BotResources resources = botEntity.getResources();

        if (eq.getItemInMainHand().getType() != Material.BOW) {
            if (combatController.canSwitchItem()) {
                eq.setItemInMainHand(new ItemStack(Material.BOW));
                combatController.triggerItemSwitchCooldown();
                bowChargeTicks = 0;
            }
            return;
        }

        bowChargeTicks++;
        if (bowChargeTicks >= 20 && bowCooldown <= 0 && resources.useArrow()) {
            Vector trajectory = targetPrediction.calculateTrajectory(bot.getEyeLocation(), target.getEyeLocation(), 2.8, 0.05);
            Arrow arrow = bot.launchProjectile(Arrow.class, trajectory);
            arrow.setShooter(bot);
            arrow.setCritical(true);
            arrow.setDamage(7.0);

            // Track arrow for session cleanup
            plugin.getArenaManager().getEntityTracker().trackEntity(sessionId, arrow);

            bot.getWorld().playSound(bot.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1.0f, 1.0f);
            bowChargeTicks = 0;
            bowCooldown = 25;
        }
    }
}
