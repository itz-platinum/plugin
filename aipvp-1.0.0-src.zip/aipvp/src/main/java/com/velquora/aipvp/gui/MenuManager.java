package com.velquora.aipvp.gui;

import com.velquora.aipvp.AiPvp;
import com.velquora.aipvp.ai.DifficultyController;
import com.velquora.aipvp.kit.KitManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages chest GUIs for PvP Mode Selection and Difficulty Selection using standard Bukkit APIs.
 */
public class MenuManager {

    public static final String MAIN_MENU_TITLE = "§8» §6AiPvP §8PvP Modes";
    public static final String DIFFICULTY_MENU_TITLE = "§8» §6AiPvP §8Select Difficulty";

    private final AiPvp plugin;
    // Map tracking mode selection before difficulty is chosen
    private final Map<UUID, KitManager.Mode> pendingModeSelections = new ConcurrentHashMap<>();

    public MenuManager(AiPvp plugin) {
        this.plugin = plugin;
    }

    /**
     * Opens the Main Mode Selection GUI for a player.
     */
    public void openMainMenu(Player player) {
        if (player == null || !player.isOnline()) return;

        Inventory inv = Bukkit.createInventory(null, 27, MAIN_MENU_TITLE);

        // Background filler
        ItemStack filler = createItem(Material.GRAY_STAINED_GLASS_PANE, "§7");
        for (int i = 0; i < 27; i++) {
            inv.setItem(i, filler);
        }

        // Slot 11: Normal PvP
        inv.setItem(11, createItem(
                Material.GRASS_BLOCK,
                "§aNormal PvP",
                "§7Fight the AI using traditional PvP.",
                "",
                "§eClick to select mode"
        ));

        // Slot 13: Crystal PvP
        inv.setItem(13, createItem(
                Material.END_CRYSTAL,
                "§dCrystal PvP",
                "§7Fight using Crystal PvP mechanics.",
                "",
                "§eClick to select mode"
        ));

        // Slot 15: Mace PvP
        inv.setItem(15, createItem(
                Material.MACE,
                "§6Mace PvP",
                "§7Fight using Mace PvP mechanics.",
                "",
                "§eClick to select mode"
        ));

        // Slot 22: Close
        inv.setItem(22, createItem(Material.BARRIER, "§cClose"));

        player.openInventory(inv);
        playClickSound(player);
    }

    /**
     * Opens the Difficulty Selection GUI for a player.
     */
    public void openDifficultyMenu(Player player, KitManager.Mode selectedMode) {
        if (player == null || !player.isOnline()) return;
        pendingModeSelections.put(player.getUniqueId(), selectedMode);

        Inventory inv = Bukkit.createInventory(null, 27, DIFFICULTY_MENU_TITLE);

        // Background filler
        ItemStack filler = createItem(Material.GRAY_STAINED_GLASS_PANE, "§7");
        for (int i = 0; i < 27; i++) {
            inv.setItem(i, filler);
        }

        // Slot 11: Easy
        inv.setItem(11, createItem(
                Material.LIME_WOOL,
                "§aEasy",
                "§7Casual AI reaction speed.",
                "§7Forgiving combat decisions.",
                "",
                "§eClick to start duel"
        ));

        // Slot 13: Medium
        inv.setItem(13, createItem(
                Material.YELLOW_WOOL,
                "§eMedium",
                "§7Balanced combat AI.",
                "§7Active strafing and item usage.",
                "",
                "§eClick to start duel"
        ));

        // Slot 15: Hard
        inv.setItem(15, createItem(
                Material.RED_WOOL,
                "§cHard",
                "§7Advanced tactical intelligence.",
                "§7Target prediction & rapid switching.",
                "",
                "§eClick to start duel"
        ));

        // Slot 22: Back
        inv.setItem(22, createItem(Material.ARROW, "§7Back"));

        player.openInventory(inv);
        playClickSound(player);
    }

    public void handleMainMenuClick(Player player, int slot) {
        switch (slot) {
            case 11 -> openDifficultyMenu(player, KitManager.Mode.NORMAL_PVP);
            case 13 -> openDifficultyMenu(player, KitManager.Mode.CRYSTAL_PVP);
            case 15 -> openDifficultyMenu(player, KitManager.Mode.MACE_PVP);
            case 22 -> {
                playClickSound(player);
                player.closeInventory();
            }
        }
    }

    public void handleDifficultyMenuClick(Player player, int slot) {
        KitManager.Mode mode = pendingModeSelections.get(player.getUniqueId());
        if (mode == null) {
            mode = KitManager.Mode.NORMAL_PVP;
        }

        switch (slot) {
            case 11 -> {
                pendingModeSelections.remove(player.getUniqueId());
                player.closeInventory();
                plugin.getBotManager().createSession(player, mode, DifficultyController.Difficulty.EASY);
            }
            case 13 -> {
                pendingModeSelections.remove(player.getUniqueId());
                player.closeInventory();
                plugin.getBotManager().createSession(player, mode, DifficultyController.Difficulty.MEDIUM);
            }
            case 15 -> {
                pendingModeSelections.remove(player.getUniqueId());
                player.closeInventory();
                plugin.getBotManager().createSession(player, mode, DifficultyController.Difficulty.HARD);
            }
            case 22 -> {
                pendingModeSelections.remove(player.getUniqueId());
                openMainMenu(player);
            }
        }
    }

    public void clearPending(UUID playerUuid) {
        pendingModeSelections.remove(playerUuid);
    }

    private ItemStack createItem(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
            if (lore.length > 0) {
                List<String> loreList = new ArrayList<>();
                for (String line : lore) {
                    loreList.add(ChatColor.translateAlternateColorCodes('&', line));
                }
                meta.setLore(loreList);
            }
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private void playClickSound(Player player) {
        try {
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.0f);
        } catch (Exception ignored) {}
    }
}
