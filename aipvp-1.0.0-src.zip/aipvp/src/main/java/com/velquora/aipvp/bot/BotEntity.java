package com.velquora.aipvp.bot;

import com.velquora.aipvp.AiPvp;
import com.velquora.aipvp.kit.KitManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.UUID;
import java.util.logging.Level;

/**
 * Wraps and manages the custom Zombie combat entity representing the AiPvP opponent.
 * Paper 1.21 MobGoal API is used to strip native zombie behaviors so the custom AI has 100% authoritative control.
 */
public class BotEntity {

    private final AiPvp plugin;
    private final Player targetPlayer;
    private final KitManager.Mode mode;
    private final BotResources resources;
    private Zombie entity;

    public BotEntity(AiPvp plugin, Player targetPlayer, KitManager.Mode mode) {
        this.plugin = plugin;
        this.targetPlayer = targetPlayer;
        this.mode = mode;
        this.resources = new BotResources(mode);
    }

    /**
     * Spawns the bot entity at the designated location with native AI stripped.
     */
    public boolean spawn(Location location, UUID sessionId) {
        if (location == null || location.getWorld() == null) return false;

        entity = (Zombie) location.getWorld().spawnEntity(location, EntityType.ZOMBIE);
        if (entity == null) return false;

        // Visual and attribute configurations
        String nameFormat = plugin.getConfigManager().getConfig().getString("bot.name-format", "%player%_bot");
        String formattedName = nameFormat.replace("%player%", targetPlayer.getName());
        entity.setCustomName(formattedName);
        entity.setCustomNameVisible(true);
        entity.setAdult();
        entity.setBaby(false);
        entity.setCanBreakDoors(false);
        entity.setRemoveWhenFarAway(false);
        entity.setPersistent(true);

        // Strict 20.0 Max Health (10 Hearts) - Constant across all difficulties
        AttributeInstance maxHealthAttr = entity.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (maxHealthAttr != null) {
            maxHealthAttr.setBaseValue(20.0);
        }
        entity.setHealth(20.0);

        // Movement speed modifier
        double speedMult = plugin.getConfigManager().getConfig().getDouble("bot.speed-multiplier", 1.05);
        AttributeInstance speedAttr = entity.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED);
        if (speedAttr != null) {
            speedAttr.setBaseValue(0.28 * speedMult);
        }

        // ============================================================
        //  PART 4: AUTHORITATIVE CONTROL (STRIP NATIVE ZOMBIE GOALS)
        // ============================================================
        try {
            // Remove vanilla stroll, melee, and targeting goals using Paper MobGoal API
            Bukkit.getMobGoals().removeAllGoals(entity);
        } catch (Exception e) {
            plugin.getLogger().log(Level.FINE, "MobGoals API fallback: " + e.getMessage());
        }

        // Maintain entity awareness for physics, collisions, and damage ticks
        entity.setAware(true);
        entity.setTarget(null); // Custom controller directs attacks and orientation explicitly

        // Attach plugin metadata for session isolation and event security
        entity.setMetadata("aipvp_bot", new FixedMetadataValue(plugin, sessionId.toString()));
        entity.setMetadata("aipvp_owner", new FixedMetadataValue(plugin, targetPlayer.getUniqueId().toString()));

        // Track entity in EntityTracker
        plugin.getArenaManager().getEntityTracker().trackEntity(sessionId, entity);

        // Equip kit
        plugin.getKitManager().equipBot(entity, mode);

        return true;
    }

    /**
     * Safely cleans up and removes the bot entity.
     */
    public void remove() {
        if (entity != null) {
            entity.removeMetadata("aipvp_bot", plugin);
            entity.removeMetadata("aipvp_owner", plugin);
            if (entity.isValid() && !entity.isDead()) {
                entity.remove();
            }
            entity = null;
        }
    }

    public Zombie getEntity() {
        return entity;
    }

    public boolean isAlive() {
        return entity != null && entity.isValid() && !entity.isDead();
    }

    public Location getLocation() {
        return entity != null ? entity.getLocation() : null;
    }

    public BotResources getResources() {
        return resources;
    }
}
