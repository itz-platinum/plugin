package com.velquora.aipvp.command;

import com.velquora.aipvp.AiPvp;
import com.velquora.aipvp.arena.Arena;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;

/**
 * Administrative command handler for /aisetup.
 * Supports arena creation, spawn setting, list inspections, and safe configuration reload.
 */
public class AiSetupCommand implements CommandExecutor, TabCompleter {

    private final AiPvp plugin;

    public AiSetupCommand(AiPvp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        try {
            if (!sender.hasPermission("aipvp.admin")) {
                sender.sendMessage(plugin.getConfigManager().getMessage("no-permission", "§cYou do not have permission to execute this command."));
                return true;
            }

            if (args.length == 0) {
                sendHelp(sender);
                return true;
            }

            String sub = args[0].toLowerCase();
            switch (sub) {
                case "spawn" -> {
                    if (!(sender instanceof Player player)) {
                        sender.sendMessage(plugin.getConfigManager().getMessage("only-players", "§cThis command can only be used by players."));
                        return true;
                    }

                    Location loc = player.getLocation();
                    plugin.getArenaManager().setBotSpawnLocation(loc);

                    String msg = plugin.getConfigManager().getMessage("spawn-set", "§aBot spawn location saved at §e%world% §7(%x%, %y%, %z%)§a.")
                            .replace("%world%", loc.getWorld().getName())
                            .replace("%x%", String.format("%.2f", loc.getX()))
                            .replace("%y%", String.format("%.2f", loc.getY()))
                            .replace("%z%", String.format("%.2f", loc.getZ()))
                            .replace("%yaw%", String.format("%.1f", loc.getYaw()))
                            .replace("%pitch%", String.format("%.1f", loc.getPitch()));

                    player.sendMessage(msg);
                    return true;
                }
                case "reload" -> {
                    try {
                        plugin.getConfigManager().loadAll();
                        plugin.getArenaManager().loadArenas();
                        sender.sendMessage(plugin.getConfigManager().getMessage("reload-success", "§aAll AiPvP configurations, arenas, and kits have been reloaded successfully."));
                    } catch (Exception e) {
                        plugin.getLogger().log(Level.SEVERE, "Failed to reload configurations", e);
                        sender.sendMessage(plugin.getConfigManager().getMessage("reload-error", "§cAn error occurred while reloading AiPvP configurations. Check console for details."));
                    }
                    return true;
                }
                case "createarena" -> {
                    if (args.length < 2) {
                        sender.sendMessage("§cUsage: /aisetup createarena <arenaId> [radius]");
                        return true;
                    }
                    if (!(sender instanceof Player player)) {
                        sender.sendMessage(plugin.getConfigManager().getMessage("only-players", "§cThis command can only be used by players."));
                        return true;
                    }

                    String arenaId = args[1].toLowerCase();
                    double radius = 30.0;
                    if (args.length >= 3) {
                        try {
                            radius = Double.parseDouble(args[2]);
                        } catch (NumberFormatException ignored) {}
                    }

                    Location pLoc = player.getLocation();
                    Location bLoc = pLoc.clone().add(0, 0, 8);

                    Arena arena = new Arena(arenaId, arenaId, pLoc.getWorld().getName(), pLoc, bLoc, radius);
                    saveArenaToConfig(arena);
                    plugin.getArenaManager().loadArenas();

                    sender.sendMessage("§aCreated arena §e" + arenaId + " §awith radius §e" + radius + "§a. Set spawns with §e/aisetup setplayerspawn " + arenaId + "§a and §e/aisetup setbotspawn " + arenaId);
                    return true;
                }
                case "setplayerspawn" -> {
                    if (args.length < 2) {
                        sender.sendMessage("§cUsage: /aisetup setplayerspawn <arenaId>");
                        return true;
                    }
                    if (!(sender instanceof Player player)) {
                        sender.sendMessage(plugin.getConfigManager().getMessage("only-players", "§cThis command can only be used by players."));
                        return true;
                    }

                    String arenaId = args[1].toLowerCase();
                    Arena arena = plugin.getArenaManager().getArena(arenaId);
                    if (arena == null) {
                        sender.sendMessage("§cArena '" + arenaId + "' does not exist.");
                        return true;
                    }

                    arena.setPlayerSpawn(player.getLocation());
                    saveArenaToConfig(arena);
                    sender.sendMessage("§aPlayer spawn set for arena §e" + arenaId);
                    return true;
                }
                case "setbotspawn" -> {
                    if (args.length < 2) {
                        sender.sendMessage("§cUsage: /aisetup setbotspawn <arenaId>");
                        return true;
                    }
                    if (!(sender instanceof Player player)) {
                        sender.sendMessage(plugin.getConfigManager().getMessage("only-players", "§cThis command can only be used by players."));
                        return true;
                    }

                    String arenaId = args[1].toLowerCase();
                    Arena arena = plugin.getArenaManager().getArena(arenaId);
                    if (arena == null) {
                        sender.sendMessage("§cArena '" + arenaId + "' does not exist.");
                        return true;
                    }

                    arena.setBotSpawn(player.getLocation());
                    saveArenaToConfig(arena);
                    sender.sendMessage("§aBot spawn set for arena §e" + arenaId);
                    return true;
                }
                case "listarenas" -> {
                    sender.sendMessage("§8================ §6AiPvP Arenas §8================");
                    for (Arena a : plugin.getArenaManager().getAllArenas()) {
                        String statusColor = switch (a.getStatus()) {
                            case AVAILABLE -> "§aAVAILABLE";
                            case IN_USE -> "§cIN_USE";
                            case DISABLED -> "§7DISABLED";
                        };
                        sender.sendMessage("§e" + a.getId() + " §7(" + a.getDisplayName() + ") - World: §f" + a.getWorldName() + " §7- Status: " + statusColor);
                    }
                    sender.sendMessage("§8================================================");
                    return true;
                }
                default -> {
                    sender.sendMessage(plugin.getConfigManager().getMessage("invalid-args", "§cInvalid arguments. Usage: §e/aisetup <spawn|reload|createarena|setbotspawn|setplayerspawn|listarenas>"));
                    return true;
                }
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Unexpected error in /aisetup command", e);
            sender.sendMessage("§cAn error occurred while executing the setup command. Check console for details.");
            return true;
        }
    }

    private void saveArenaToConfig(Arena arena) {
        ConfigurationSection arenasSec = plugin.getConfigManager().getArenasConfig().getConfigurationSection("arenas");
        if (arenasSec == null) {
            arenasSec = plugin.getConfigManager().getArenasConfig().createSection("arenas");
        }
        ConfigurationSection aSec = arenasSec.createSection(arena.getId());
        aSec.set("display-name", arena.getDisplayName());
        aSec.set("world", arena.getWorldName());
        aSec.set("radius", arena.getRadius());
        aSec.set("enabled", arena.isEnabled());
        aSec.set("allowed-modes", arena.getAllowedModes());

        if (arena.getPlayerSpawn() != null) {
            ConfigurationSection pSec = aSec.createSection("player-spawn");
            pSec.set("x", Math.round(arena.getPlayerSpawn().getX() * 100.0) / 100.0);
            pSec.set("y", Math.round(arena.getPlayerSpawn().getY() * 100.0) / 100.0);
            pSec.set("z", Math.round(arena.getPlayerSpawn().getZ() * 100.0) / 100.0);
            pSec.set("yaw", Math.round(arena.getPlayerSpawn().getYaw() * 10.0f) / 10.0f);
            pSec.set("pitch", Math.round(arena.getPlayerSpawn().getPitch() * 10.0f) / 10.0f);
        }

        if (arena.getBotSpawn() != null) {
            ConfigurationSection bSec = aSec.createSection("bot-spawn");
            bSec.set("x", Math.round(arena.getBotSpawn().getX() * 100.0) / 100.0);
            bSec.set("y", Math.round(arena.getBotSpawn().getY() * 100.0) / 100.0);
            bSec.set("z", Math.round(arena.getBotSpawn().getZ() * 100.0) / 100.0);
            bSec.set("yaw", Math.round(arena.getBotSpawn().getYaw() * 10.0f) / 10.0f);
            bSec.set("pitch", Math.round(arena.getBotSpawn().getPitch() * 10.0f) / 10.0f);
        }

        plugin.getConfigManager().saveArenas();
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage("§8================ §6AiPvP Setup §8================");
        sender.sendMessage("§e/aisetup spawn §7- Quick set default bot spawn location.");
        sender.sendMessage("§e/aisetup createarena <id> [radius] §7- Create a new arena.");
        sender.sendMessage("§e/aisetup setplayerspawn <id> §7- Set player spawn for an arena.");
        sender.sendMessage("§e/aisetup setbotspawn <id> §7- Set bot spawn for an arena.");
        sender.sendMessage("§e/aisetup listarenas §7- View all arenas and their status.");
        sender.sendMessage("§e/aisetup reload §7- Safely reload all configuration files.");
        sender.sendMessage("§8================================================");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("aipvp.admin")) {
            return Collections.emptyList();
        }

        if (args.length == 1) {
            List<String> list = new ArrayList<>();
            String[] subs = {"spawn", "reload", "createarena", "setplayerspawn", "setbotspawn", "listarenas"};
            for (String s : subs) {
                if (s.startsWith(args[0].toLowerCase())) list.add(s);
            }
            return list;
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("setplayerspawn") || args[0].equalsIgnoreCase("setbotspawn"))) {
            List<String> list = new ArrayList<>();
            for (Arena a : plugin.getArenaManager().getAllArenas()) {
                if (a.getId().startsWith(args[1].toLowerCase())) list.add(a.getId());
            }
            return list;
        }
        return Collections.emptyList();
    }
}
