package com.velquora.aipvp.gemini;

import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/**
 * Tracks short-term and longitudinal behavioral tendencies of the human player during duels.
 * Generates compact summarized analytical profiles for Gemini strategic planning.
 */
public class CombatMemory {

    private int totalObservedTicks = 0;
    private int shieldingTicks = 0;
    private int strafeLeftCount = 0;
    private int strafeRightCount = 0;
    private int retreatAtLowHealthCount = 0;
    private int aggressiveRushCount = 0;
    private int maceJumpAttempts = 0;
    private int crystalPlacements = 0;
    private int goldenApplesEaten = 0;

    private Vector lastPlayerPos = null;

    public void update(Player player, double playerHealth, double distanceToBot) {
        if (player == null || !player.isOnline()) return;

        totalObservedTicks++;

        if (player.isBlocking()) {
            shieldingTicks++;
        }

        Vector currentPos = player.getLocation().toVector();
        if (lastPlayerPos != null) {
            Vector delta = currentPos.clone().subtract(lastPlayerPos);
            delta.setY(0);

            // Check strafe bias
            if (delta.lengthSquared() > 0.04) {
                Vector facing = player.getLocation().getDirection().setY(0).normalize();
                Vector cross = facing.getCrossProduct(delta.normalize());
                if (cross.getY() > 0.2) {
                    strafeRightCount++;
                } else if (cross.getY() < -0.2) {
                    strafeLeftCount++;
                }
            }

            // Check low health retreat behavior
            if (playerHealth <= 8.0 && distanceToBot > 7.0 && delta.lengthSquared() > 0.05) {
                retreatAtLowHealthCount++;
            }
        }
        lastPlayerPos = currentPos;
    }

    public void recordMaceJump() {
        maceJumpAttempts++;
    }

    public void recordCrystalPlacement() {
        crystalPlacements++;
    }

    public void recordGoldenAppleEaten() {
        goldenApplesEaten++;
    }

    /**
     * Produces a concise, natural summary of the player's observed fighting style for Gemini prompt context.
     */
    public String getBehavioralSummary() {
        if (totalObservedTicks < 40) {
            return "Initial combat observation; no established patterns yet.";
        }

        StringBuilder sb = new StringBuilder();
        double shieldRatio = (double) shieldingTicks / Math.max(1, totalObservedTicks);
        if (shieldRatio > 0.35) {
            sb.append("Player heavily relies on shield (").append((int) (shieldRatio * 100)).append("% of time). ");
        }

        if (strafeLeftCount > strafeRightCount * 1.8 && strafeLeftCount > 10) {
            sb.append("Heavy left-strafing bias. ");
        } else if (strafeRightCount > strafeLeftCount * 1.8 && strafeRightCount > 10) {
            sb.append("Heavy right-strafing bias. ");
        }

        if (retreatAtLowHealthCount > 3) {
            sb.append("Consistently disengages and retreats at low health. ");
        }

        if (maceJumpAttempts > 3) {
            sb.append("Frequently initiates high aerial mace attacks. ");
        }

        if (crystalPlacements > 4) {
            sb.append("Experienced crystal placement speed. ");
        }

        return sb.length() > 0 ? sb.toString().trim() : "Balanced, adaptive combat style with standard spacing.";
    }

    public void reset() {
        totalObservedTicks = 0;
        shieldingTicks = 0;
        strafeLeftCount = 0;
        strafeRightCount = 0;
        retreatAtLowHealthCount = 0;
        aggressiveRushCount = 0;
        maceJumpAttempts = 0;
        crystalPlacements = 0;
        goldenApplesEaten = 0;
        lastPlayerPos = null;
    }
}
