package com.velquora.aipvp.combat;

import com.velquora.aipvp.AiPvp;
import com.velquora.aipvp.ai.*;
import com.velquora.aipvp.bot.BotEntity;
import com.velquora.aipvp.bot.BotResources;
import com.velquora.aipvp.gemini.StrategicPlan;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.WindCharge;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Controller for Mace PvP mode: Wind charge vertical propulsion, falling slam attacks, and smash mechanics.
 */
public class MacePvPController {

    private final AiPvp plugin;
    private final UUID sessionId;
    private final AimController aimController;
    private final MovementController movementController;
    private final CombatController combatController;
    private final TargetPrediction targetPrediction;
    private final PotionController potionController;
    private final DifficultyController difficultyController;

    private int windChargeCooldown = 0;

    public MacePvPController(AiPvp plugin,
                             UUID sessionId,
                             AimController aimController,
                             MovementController movementController,
                             CombatController combatController,
                             TargetPrediction targetPrediction,
                             PotionController potionController,
                             DifficultyController difficultyController) {
        this.plugin = plugin;
        this.sessionId = sessionId;
        this.aimController = aimController;
        this.movementController = movementController;
        this.combatController = combatController;
        this.targetPrediction = targetPrediction;
        this.potionController = potionController;
        this.difficultyController = difficultyController;
    }

    public void tick(BotEntity botEntity, Player target, StrategicPlan strategicPlan) {
        if (botEntity == null || !botEntity.isAlive() || target == null || !target.isOnline()) return;
        LivingEntity bot = botEntity.getEntity();
        BotResources resources = botEntity.getResources();

        combatController.tick();
        potionController.tick();
        if (windChargeCooldown > 0) windChargeCooldown--;

        double distance = bot.getLocation().distance(target.getLocation());
        boolean isLowHealth = (bot.getHealth() / 20.0) <= difficultyController.getHealingThreshold();

        // 1. Health & Healing
        if (isLowHealth || strategicPlan == StrategicPlan.HEAL) {
            potionController.checkHealing(botEntity);
        }

        // 2. Main hand Mace enforcement
        EntityEquipment eq = bot.getEquipment();
        if (eq != null && eq.getItemInMainHand().getType() != Material.MACE) {
            eq.setItemInMainHand(new ItemStack(Material.MACE));
        }

        // 3. Aim towards predicted target
        Location predictedTarget = targetPrediction.predictPosition(target, 3.0, difficultyController.getTargetPredictionFactor());
        aimController.lookAt(bot, predictedTarget.clone().add(0, 1.2, 0));

        // 4. Wind Charge Launch to gain height for heavy smash
        boolean strategicSmash = (strategicPlan == StrategicPlan.MACE_SETUP || strategicPlan == StrategicPlan.MACE_ATTACK);
        if (windChargeCooldown <= 0 && bot.isOnGround() && distance < 10.0 && distance > 2.0 && resources.getWindCharges() > 0) {
            double chance = strategicSmash ? 0.95 : difficultyController.getMaceWindChargeChance();
            if (ThreadLocalRandom.current().nextDouble() < chance) {
                executeWindChargeLaunch(botEntity, target);
            }
        }

        // 5. Falling Smash Attack Execution
        if (bot.getFallDistance() > 1.2F && distance <= 3.8) {
            boolean hit = combatController.performMeleeAttack(bot, target);
            if (hit) {
                Location hitLoc = target.getLocation().add(0, 1.0, 0);
                bot.getWorld().spawnParticle(Particle.GUST_EMITTER_LARGE, hitLoc, 1);
                bot.getWorld().playSound(hitLoc, Sound.ITEM_MACE_SMASH_GROUND, 1.2f, 1.0f);
                bot.setFallDistance(0); // Reset fall damage on successful smash
            }
        } else if (distance <= 3.5) {
            combatController.performMeleeAttack(bot, target);
        }

        // 6. Movement
        movementController.updateMovement(bot, target.getLocation(), 2.0, isLowHealth);
    }

    private void executeWindChargeLaunch(BotEntity botEntity, Player target) {
        LivingEntity bot = botEntity.getEntity();
        BotResources resources = botEntity.getResources();

        if (!resources.useWindCharge()) return;

        windChargeCooldown = 50; // 2.5s cooldown
        Location botLoc = bot.getLocation();

        // Launch projectile backwards/downwards for realistic Paper physics
        Vector launchVec = target.getLocation().toVector().subtract(botLoc.toVector()).normalize().multiply(0.65);
        launchVec.setY(1.15); // High upward elevation for mace density bonus

        bot.setVelocity(launchVec);
        bot.getWorld().playSound(botLoc, Sound.ENTITY_WIND_CHARGE_WIND_BURST, 1.0f, 1.0f);
        bot.getWorld().spawnParticle(Particle.GUST, botLoc, 10, 0.3, 0.3, 0.3, 0.05);
    }
}
