package com.velquora.aipvp;

import com.velquora.aipvp.arena.ArenaManager;
import com.velquora.aipvp.bot.BotManager;
import com.velquora.aipvp.command.AiPvpCommand;
import com.velquora.aipvp.command.AiSetupCommand;
import com.velquora.aipvp.config.ConfigManager;
import com.velquora.aipvp.gui.MenuManager;
import com.velquora.aipvp.kit.KitManager;
import com.velquora.aipvp.listener.AiPvpListener;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

/**
 * Main Paper Plugin entry point for AiPvP.
 * Autonomous AI PvP duel training system with Gemini Strategic Intelligence for Paper 1.21+.
 */
public class AiPvp extends JavaPlugin {

    private static AiPvp instance;

    private ConfigManager configManager;
    private ArenaManager arenaManager;
    private KitManager kitManager;
    private BotManager botManager;
    private MenuManager menuManager;

    @Override
    public void onEnable() {
        instance = this;

        long startTime = System.currentTimeMillis();
        getLogger().info("§6[AiPvP] Enabling AiPvP v" + getDescription().getVersion() + " by Velquora...");

        try {
            // 1. Initialize Managers
            this.configManager = new ConfigManager(this);
            this.configManager.loadAll();

            this.arenaManager = new ArenaManager(this);
            this.arenaManager.loadArenas();

            this.kitManager = new KitManager(this);
            this.botManager = new BotManager(this);
            this.menuManager = new MenuManager(this);

            // 2. Register Commands Safely
            registerCommands();

            // 3. Register Event Listeners
            getServer().getPluginManager().registerEvents(new AiPvpListener(this), this);

            long duration = System.currentTimeMillis() - startTime;
            getLogger().info("§a[AiPvP] Successfully enabled in " + duration + "ms! Multi-arena duel engine active.");
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "[AiPvP] Fatal error during plugin startup!", e);
            getServer().getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        getLogger().info("§e[AiPvP] Disabling AiPvP and terminating active sessions...");

        // 1. Terminate all active AI bot sessions safely
        if (botManager != null) {
            botManager.terminateAll();
        }

        // 2. Restore modified arena blocks and remove tracked session entities
        if (arenaManager != null) {
            arenaManager.cleanupAll();
        }

        instance = null;
        getLogger().info("§a[AiPvP] Disabled cleanly. All state restored.");
    }

    private void registerCommands() {
        // Main /aipvp command
        PluginCommand aipvpCmd = getCommand("aipvp");
        if (aipvpCmd != null) {
            AiPvpCommand executor = new AiPvpCommand(this);
            aipvpCmd.setExecutor(executor);
            aipvpCmd.setTabCompleter(executor);
        } else {
            getLogger().warning("Command /aipvp could not be retrieved from plugin.yml!");
        }

        // Setup /aisetup command
        PluginCommand aisetupCmd = getCommand("aisetup");
        if (aisetupCmd != null) {
            AiSetupCommand setupExecutor = new AiSetupCommand(this);
            aisetupCmd.setExecutor(setupExecutor);
            aisetupCmd.setTabCompleter(setupExecutor);
        } else {
            getLogger().warning("Command /aisetup could not be retrieved from plugin.yml!");
        }
    }

    public static AiPvp getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public ArenaManager getArenaManager() {
        return arenaManager;
    }

    public KitManager getKitManager() {
        return kitManager;
    }

    public BotManager getBotManager() {
        return botManager;
    }

    public MenuManager getMenuManager() {
        return menuManager;
    }
}
