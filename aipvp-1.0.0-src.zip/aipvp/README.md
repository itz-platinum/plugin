# AiPvP (v1.0.0) — Enterprise Paper AI PvP Bot Engine
**Autonomous 1v1 PvP Duel Simulator with Dual-Layer Tactical Reflexes & Gemini Strategic Intelligence**

---

## ⚡ Overview
**AiPvP** is an autonomous AI PvP training Paper plugin developed for Minecraft Paper 1.21+. It empowers players to duel custom-configured tactical AI bot opponents across three distinct combat disciplines:
- **Normal PvP**: Spacing control, sprint jump crits, axe shield breaking, bow trajectory prediction, and tactical healing.
- **Crystal PvP**: Strategic ground placement, safety damage threshold calculations, rapid detonation, and Totem cycling.
- **Mace PvP**: Wind charge vertical propulsion, high-altitude mace slam attacks with area shockwaves, and fall cushioning.

---

## 🧠 Two-Layer Hybrid AI Architecture
1. **Layer 1: Local Real-Time AI (20 TPS)**
   - Authoritative movement, rotation, aim smoothing, ray tracing, obstacle jumping, sprint-strafing, and attack execution.
   - Paper 1.21 MobGoal API strips native vanilla zombie wandering, aggro, and pathfinding.
   - Zero dependence on external networks for real-time combat reflexes.
2. **Layer 2: Gemini Strategic Intelligence (Asynchronous & Optional)**
   - Runs every 2–5 seconds in background threads without stalling the main server thread.
   - Evaluates opponent behavioral habits (shield frequency, strafe bias, retreat at low health).
   - Recommends validated strategic plans: `PRESSURE`, `DEFEND`, `RETREAT`, `HEAL`, `REPOSITION`, `BOW_PRESSURE`, `BREAK_SHIELD`, `CRYSTAL_SETUP`, `CRYSTAL_PRESSURE`, `MACE_SETUP`, `MACE_ATTACK`, `RESET_POSITION`.
   - **Zero-Latency Fallback**: Seamlessly falls back to local AI on network timeout, invalid response, or disabled API.

---

## 🛡️ Robust Server Safety Guarantees
- **Transaction-Style Block Rollback**: Captures block states *before* modification (break, place, crystal explosion) and restores pre-session states cleanly without physics triggers.
- **Complete Entity Cleanup**: Tracks session-spawned bots, crystals, arrows, and wind charges via session UUIDs and guarantees removal on win, loss, disconnect, or timeout.
- **Multi-Arena Boundary Enforcement**: Soft and hard boundary modes prevent players or bots from escaping into survival worlds.
- **Death-to-Respawn Lifecycle**: Preserves inventories and vitals without corrupting dead player states; restores state safely on `PlayerRespawnEvent`.
- **Environmental Protection**: Configurable damage cause cancellation for duel participants.

---

## 🚀 Building with Maven
### Requirements
- **JDK 21 LTS** (or JDK 21–25)
- **Apache Maven 3.8+**
- **Paper 1.21.x** Server

```bash
mvn clean package
```

### Artifact Output
```text
target/aipvp-1.0.0.jar
```

---

## 🎮 Commands & Permissions

| Command | Permission | Default | Description |
| :--- | :--- | :--- | :--- |
| `/aipvp` | `aipvp.use` | `true` | Opens the interactive Chest GUI to choose PvP mode and difficulty. |
| `/aisetup spawn` | `aipvp.admin` | `op` | Saves current location as default bot spawn point. |
| `/aisetup createarena <id> [radius]` | `aipvp.admin` | `op` | Creates a new isolated duel arena. |
| `/aisetup setplayerspawn <id>` | `aipvp.admin` | `op` | Sets player spawn point for specified arena. |
| `/aisetup setbotspawn <id>` | `aipvp.admin` | `op` | Sets bot spawn point for specified arena. |
| `/aisetup listarenas` | `aipvp.admin` | `op` | Lists all arenas, worlds, and availability status. |
| `/aisetup reload` | `aipvp.admin` | `op` | Safely reloads all configurations, arenas, and kits. |

---

## 🔑 Optional Gemini API Setup
Set the environment variable on your server host:
```bash
export GEMINI_API_KEY="your-api-key-here"
```
Or configure in `plugins/aipvp/config.yml`:
```yaml
gemini:
  enabled: true
  model: "gemini-2.5-flash"
  api-key-env: "GEMINI_API_KEY"
  decision-interval-ms: 3000
  timeout-ms: 1500
```
*Note: If disabled or unconfigured, the plugin operates with 100% functionality via the local tactical AI engine.*
